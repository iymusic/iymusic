const { Button, Badge, Card, StarIcon, PatternPanel, SectionHeading, StatBlock } = window.IndependentlyYoursDesignSystem_da5bbe;

/* The 12-week cohort, as a chart. Source: IY program roadmap (Phase Alpha = Education + Incubation). */
const HOME_STAGES = [
  {
    weeks: 'Weeks 1–8',
    name: 'Education',
    sub: '8 weekly sessions in LA',
    items: ['Marketing, narrative & SWOT fundamentals', 'Social, content & paid ads', 'Media, PR & visual content', 'Sync licensing', 'Publishing', 'Tech & content management', 'Music business fundamentals & monetization', 'Touring & live business']
  },
  {
    weeks: 'Weeks 9–12',
    name: 'Incubation',
    sub: 'Put it to work, with support',
    items: ['Infrastructure audit: your business, legal and brand setup, checked', 'Readiness assessment: are you development-ready, with data to back it?', 'Networking mixer with industry guests and the cohort']
  }
];

const HOME_FIT = [
  { t: 'Independent musicians', d: 'Songwriters, bands, producers and artist projects releasing their own music. Any genre. (This program is for musicians, not visual artists.)' },
  { t: 'With a community that shows up', d: 'Fans who buy the ticket, the merch, join the list or the Discord, not just passive streams. Your application includes a short fan survey, and at least 15 of your community need to answer it.' },
  { t: 'Ready to build the business', d: 'You have the music and the audience. What you need is the infrastructure: money, rights, team and a plan you run yourself.' }
];

function HomeScreen({ go }) {
  return (
    <div>
      <PatternPanel tone="teal" hasCopy tile={300}>
        <div className="wrap" style={{ padding:'72px var(--container-pad) 80px' }}>
          <div className="iy-shade iy-shade--teal" style={{ display:'grid', gridTemplateColumns:'minmax(0,1.15fr) minmax(0,.85fr)', gap:'var(--space-8)', alignItems:'center' }}>
            <div>
              <Badge tone="yellow" style={{ marginBottom:'var(--space-5)' }}>First cohort · Q1 2027 · applications open</Badge>
              <h1 style={{ color:'var(--iy-cream-100)', fontSize:'clamp(var(--step-5), 5.4vw, var(--step-7))', margin:'0 0 var(--space-6)' }}>
                Activating Independence as a Strategy
              </h1>
              <div style={{ display:'flex', gap:'var(--space-3)', flexWrap:'wrap' }}>
                <Button size="lg" variant="pulse" href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
                <Button size="lg" variant="inverse-outline" onClick={()=>go('program')}>See the program</Button>
              </div>
            </div>
            <p style={{ color:'var(--iy-cream-100)', fontSize:'var(--step-2)', maxWidth:'42ch', margin:0, lineHeight:1.55 }}>
              Independently Yours is a nonprofit accelerator for independent musicians, built on a simple idea: independence does not mean alone, but it does require business acumen.<br/><br/>Twelve weeks, fifteen musicians, and a room of people who have done the work, dedicated to you each week.
            </p>
          </div>
        </div>
      </PatternPanel>

      <section style={{ background:'var(--iy-sage-400)' }} className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(min(150px, 100%), 1fr))', gap:'var(--space-5)', '--text-muted':'var(--iy-teal-900)' }}>
          <StatBlock value="12" label="weeks, start to finish" note="8 weekly sessions + 4 weeks of incubation · Tentatively Thursdays 1–4 pm, Hollywood" />
          <StatBlock value="15" label="musicians in the first cohort" note="Selected applicants hear by 30 December 2026" />
          <StatBlock value="Q1 2027" label="first cohort starts" note="Applications close 30 November 2026" />
          <StatBlock value="$0" label="cost to accepted musicians" />
        </div>
      </section>

      <section className="band">
        <div className="wrap">
          <SectionHeading eyebrow="The 12-week program" title="What happens in the room"
            lead="Eight weeks of hands-on sessions, then four weeks putting it to work. Session details are tailored to the fifteen musicians selected." />
          <div className="iy-stages">
            {HOME_STAGES.map((s, i) => (
              <div key={s.name} className="iy-stage">
                <div className="iy-stage__head">
                  <span className="iy-stage__num">{i + 1}</span>
                  <div>
                    <div className="iy-eyebrow" style={{ margin:0 }}>{s.weeks}</div>
                    <h3 style={{ margin:'2px 0 0', fontSize:'var(--step-3)' }}>{s.name}</h3>
                  </div>
                </div>
                <p style={{ margin:'0 0 var(--space-4)', color:'var(--text-muted)', fontSize:'var(--step-0)' }}>{s.sub}</p>
                <ul className="iy-stage__list">
                  {s.items.map(it => <li key={it}>{it}</li>)}
                </ul>
              </div>
            ))}
          </div>
          <p style={{ margin:'var(--space-5) 0 var(--space-6)', fontSize:'var(--step-0)', color:'var(--text-muted)', maxWidth:'70ch' }}>
            After the cohort: graduates can audition for Production and Activation, our next phase, with media planning support, up to $3K in marketing credits and industry showcases.
          </p>
          <Button variant="secondary" onClick={()=>go('program')}>Full program details</Button>
        </div>
      </section>

      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap">
          <SectionHeading eyebrow="Who it’s for" title="Independent musicians with a real community" />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(min(260px, 100%), 1fr))', gap:'var(--space-5)' }}>
            {HOME_FIT.map(f => (
              <Card key={f.t} variant="drawn" tone="white">
                <div style={{ display:'flex', gap:'var(--space-3)', alignItems:'center', marginBottom:'var(--space-3)' }}>
                  <StarIcon size={18} />
                  <h4 style={{ margin:0, fontSize:'var(--step-2)' }}>{f.t}</h4>
                </div>
                <p style={{ margin:0, fontSize:'var(--step-0)' }}>{f.d}</p>
              </Card>
            ))}
          </div>
          <div style={{ marginTop:'var(--space-6)' }}>
            <Button variant="secondary" onClick={()=>go('apply')}>Check if you’re a fit</Button>
          </div>
        </div>
      </section>

      <section className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--space-8)', alignItems:'center' }}>
          <div>
            <SectionHeading eyebrow="Research" title="The Indie Pulse Index"
              lead="We ask independent musicians and their fans what they really know about being indie, music discovery and fandom." />
            <p style={{ fontSize:'var(--step-1)' }}>Wave one is in the field now. Fans: three minutes, add your thoughts.</p>
            <div style={{ display:'flex', gap:'var(--space-3)', flexWrap:'wrap' }}>
              <Button variant="pulse" href="https://bit.ly/IPIEVERFAN" target="_blank" rel="noopener">Take the Indie Pulse survey</Button>
              <Button variant="secondary" onClick={()=>go('pulse')}>About the Index</Button>
            </div>
          </div>
          <Card variant="floated" tone="white" style={{ borderTop:'6px solid var(--iy-yellow-400)' }}>
            <div className="iy-eyebrow" style={{ marginBottom:'var(--space-4)' }}>Wave 1 · in the field</div>
            <p style={{ margin:0, fontSize:'var(--step-1)' }}>The Indie Pulse Index publishes twice a year and is free to the public. The first report follows once wave one closes.</p>
          </Card>
        </div>
      </section>

      <section className="band" style={{ borderTop:'1.5px solid var(--iy-cream-200)' }}>
        <div className="wrap" style={{ maxWidth:'var(--container-narrow)', textAlign:'center' }}>
          <div className="iy-eyebrow" style={{ marginBottom:'var(--space-4)' }}>With gratitude to our lead sponsor</div>
          <div style={{ fontSize:'clamp(var(--step-4), 4vw, var(--step-5))', fontWeight:700, letterSpacing:'.12em', color:'var(--iy-teal-900)', margin:'0 0 var(--space-5)' }}>CY LEE</div>
          <p style={{ margin:'0 auto', maxWidth:'56ch', fontSize:'var(--step-1)', lineHeight:1.6, textWrap:'pretty' }}>Independently Yours is made possible in part through the generous support of CY Lee. His patronage for artistry and culture helps make this program accessible to the musicians who need it most.</p>
          <div style={{ display:'flex', justifyContent:'center', gap:'var(--space-3)', flexWrap:'wrap', marginTop:'var(--space-6)' }}>
            <Button variant="secondary" href="https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser" target="_blank" rel="noopener">Donate to Independently Yours</Button>
            <Button variant="secondary" onClick={()=>go('about')}>Meet our board &amp; advisors</Button>
          </div>
        </div>
      </section>

      <PatternPanel tone="cream" hasCopy>
        <div className="wrap" style={{ padding:'var(--section-y-tight) var(--container-pad)' }}>
          <div className="iy-shade iy-shade--cream" style={{ textAlign:'center', maxWidth:'860px', margin:'0 auto' }}>
            <h2 style={{ margin:'0 0 var(--space-4)', fontSize:'clamp(var(--step-4), 4vw, var(--step-5))' }}>Applications close 30 November 2026.</h2>
            <p style={{ margin:'0 auto var(--space-6)', maxWidth:'46ch', fontSize:'var(--step-2)' }}>One application, one fan survey for your community, no fees.</p>
            <Button size="lg" href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
          </div>
        </div>
      </PatternPanel>
    </div>
  );
}
