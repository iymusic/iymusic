const fs=require('fs'),path=require('path'),babel=require('@babel/core'),{minify}=require('terser');
const site=process.argv[2]||path.join(__dirname,'..'), nm=path.join(__dirname,'node_modules');
(async()=>{
 for (const [src,dst] of [['react/umd/react.production.min.js','react.production.min.js'],['react-dom/umd/react-dom.production.min.js','react-dom.production.min.js'],['lucide/dist/umd/lucide.min.js','lucide.min.js']])
   fs.copyFileSync(path.join(nm,src),path.join(site,'js/vendor',dst));
 fs.writeFileSync(path.join(site,'js/design-system.js'),(await minify(fs.readFileSync(path.join(site,'src/design-system.js'),'utf8'),{compress:true,mangle:false})).code);
 const order=['home.jsx','program.jsx','apply.jsx','pulse.jsx','about.jsx','mission.jsx','app.jsx'];
 let out='';
 for (const f of order){
   const code=fs.readFileSync(path.join(site,'src',f),'utf8');
   const r=babel.transformSync(code,{filename:f,babelrc:false,configFile:false,
     presets:[[require.resolve('@babel/preset-react'),{runtime:'classic'}]],
     plugins:[require.resolve('@babel/plugin-transform-block-scoping')]});
   out+=`\n/* ---- ${f} ---- */\n`+r.code+'\n';
 }
 const m=await minify(out,{compress:true,mangle:false});
 fs.writeFileSync(path.join(site,'js/site.js'),m.code);
 console.log('site.js bytes',m.code.length);
})().catch(e=>{console.error(e);process.exit(1)});
