/* @ds-bundle: {"format":4,"namespace":"IndependentlyYoursDesignSystem_da5bbe","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"PatternPanel","sourcePath":"components/core/PatternPanel.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"StarIcon","sourcePath":"components/core/StarIcon.jsx"},{"name":"StatBlock","sourcePath":"components/core/StatBlock.jsx"},{"name":"Disclosure","sourcePath":"components/feedback/Disclosure.jsx"},{"name":"ChoiceField","sourcePath":"components/forms/ChoiceField.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"StepIndicator","sourcePath":"components/forms/StepIndicator.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"SiteFooter","sourcePath":"components/navigation/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/navigation/SiteHeader.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"67e00b3ae477","components/core/Button.jsx":"3d5d2123a90d","components/core/Card.jsx":"f48232d877ca","components/core/PatternPanel.jsx":"a9c8dfa8d389","components/core/SectionHeading.jsx":"7fcef0a9cdbf","components/core/StarIcon.jsx":"94e08a75936d","components/core/StatBlock.jsx":"33a631f260a9","components/feedback/Disclosure.jsx":"1859d7789637","components/forms/ChoiceField.jsx":"2342da22f224","components/forms/Input.jsx":"0d2b8b8d74a7","components/forms/Select.jsx":"af3ef2b9aeac","components/forms/StepIndicator.jsx":"14907e4a4468","components/forms/Textarea.jsx":"6b520741653d","components/navigation/SiteFooter.jsx":"223ae39a1a3a","components/navigation/SiteHeader.jsx":"9bb2dc16d5ff","ui_kits/website/AboutScreen.jsx":"2a6fb06a648d","ui_kits/website/ApplyScreen.jsx":"ad43faf061cc","ui_kits/website/HomeScreen.jsx":"bd0001aa493e","ui_kits/website/MissionScreen.jsx":"65c6282ccf7d","ui_kits/website/ProgramScreen.jsx":"28f6472cfa20","ui_kits/website/PulseScreen.jsx":"c1707f276823","ui_kits/website/ResourcesScreen.jsx":"f7e499d6e38d","ui_kits/website/Site.jsx":"a57fd0983821"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.IndependentlyYoursDesignSystem_da5bbe = window.IndependentlyYoursDesignSystem_da5bbe || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  teal: {
    background: 'var(--iy-teal-900)',
    color: 'var(--iy-cream-100)'
  },
  sage: {
    background: 'var(--iy-sage-400)',
    color: 'var(--iy-teal-900)'
  },
  cream: {
    background: 'var(--iy-cream-100)',
    color: 'var(--iy-teal-900)'
  },
  yellow: {
    background: 'var(--iy-yellow-400)',
    color: 'var(--iy-espresso-900)'
  },
  plum: {
    background: 'var(--iy-plum-800)',
    color: 'var(--iy-cream-100)'
  },
  outline: {
    background: 'transparent',
    color: 'var(--iy-teal-900)',
    boxShadow: 'inset 0 0 0 1.5px var(--iy-teal-900)'
  }
};
function Badge({
  tone = 'sage',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: '.06em',
      textTransform: 'uppercase',
      padding: '5px 12px',
      borderRadius: 'var(--radius-pill)',
      display: 'inline-flex',
      alignItems: 'center',
      whiteSpace: 'nowrap',
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const base = {
  fontFamily: 'var(--font-ui)',
  fontWeight: 700,
  letterSpacing: '.01em',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-2)',
  borderRadius: 'var(--radius-pill)',
  border: '1.5px solid transparent',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
  textDecoration: 'none',
  transition: 'background-color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)'
};
const sizes = {
  sm: {
    fontSize: 'var(--step--1)',
    padding: '8px 16px'
  },
  md: {
    fontSize: 'var(--step-0)',
    padding: '12px 24px'
  },
  lg: {
    fontSize: 'var(--step-1)',
    padding: '16px 32px'
  }
};
const variants = {
  primary: {
    background: 'var(--iy-teal-900)',
    color: 'var(--iy-cream-100)'
  },
  secondary: {
    background: 'transparent',
    color: 'var(--iy-teal-900)',
    borderColor: 'var(--iy-teal-900)'
  },
  pulse: {
    background: 'var(--iy-yellow-400)',
    color: 'var(--iy-espresso-900)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--iy-teal-900)'
  },
  inverse: {
    background: 'var(--iy-cream-100)',
    color: 'var(--iy-teal-900)'
  },
  'inverse-outline': {
    background: 'transparent',
    color: 'var(--iy-cream-100)',
    borderColor: 'rgba(242,231,215,.55)'
  }
};
const hovers = {
  primary: {
    background: 'var(--iy-teal-700)'
  },
  secondary: {
    background: 'rgba(1,64,69,.08)'
  },
  pulse: {
    background: 'var(--iy-yellow-600)'
  },
  ghost: {
    background: 'rgba(1,64,69,.08)'
  },
  inverse: {
    background: 'var(--iy-white)'
  },
  'inverse-outline': {
    background: 'rgba(242,231,215,.14)',
    borderColor: 'var(--iy-cream-100)'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  href,
  disabled = false,
  fullWidth = false,
  style,
  children,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = href ? 'a' : 'button';
  const css = {
    ...base,
    ...sizes[size],
    ...variants[variant],
    ...(hover && !disabled ? hovers[variant] : null),
    width: fullWidth ? '100%' : undefined,
    opacity: disabled ? .45 : 1,
    pointerEvents: disabled ? 'none' : undefined,
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    disabled: !href ? disabled : undefined,
    style: css,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  variant = 'drawn',
  tone = 'white',
  padding = 'var(--space-6)',
  as = 'div',
  style,
  children,
  ...rest
}) {
  const Tag = as;
  const fills = {
    white: {
      background: 'var(--surface-card)',
      color: 'var(--text-body)'
    },
    cream: {
      background: 'var(--iy-cream-100)',
      color: 'var(--text-body)'
    },
    teal: {
      background: 'var(--iy-teal-900)',
      color: 'var(--iy-cream-100)'
    },
    sage: {
      background: 'var(--iy-sage-400)',
      color: 'var(--iy-teal-900)'
    }
  };
  const shells = {
    drawn: {
      border: '1.5px solid ' + (tone === 'teal' ? 'transparent' : 'var(--iy-teal-900)')
    },
    floated: {
      border: '1.5px solid transparent',
      boxShadow: 'var(--shadow-md)'
    },
    flat: {
      border: '1.5px solid transparent'
    }
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      borderRadius: 'var(--radius-md)',
      padding,
      ...fills[tone],
      ...shells[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/PatternPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Full-bleed brand pattern field that enforces the 20% / 40% opacity rule. */
function PatternPanel({
  tone = 'teal',
  hasCopy = true,
  tile = 280,
  style,
  children,
  ...rest
}) {
  const fills = {
    teal: 'var(--iy-teal-900)',
    sage: 'var(--iy-sage-400)',
    cream: 'var(--iy-cream-100)',
    charcoal: 'var(--iy-char-800)',
    pulse: 'var(--iy-yellow-400)'
  };
  const base = typeof window !== 'undefined' && window.IY_ASSET_BASE || '../../assets/';
  const invert = tone === 'teal' || tone === 'charcoal';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      isolation: 'isolate',
      overflow: 'hidden',
      background: fills[tone],
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 0,
      backgroundImage: 'url(' + base + 'pattern-star-alpha.png)',
      backgroundSize: tile + 'px',
      filter: invert ? 'invert(1)' : undefined,
      opacity: hasCopy ? 0.2 : 0.4
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, children));
}
Object.assign(__ds_scope, { PatternPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/PatternPanel.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionHeading({
  eyebrow,
  title,
  lead,
  align = 'left',
  tone = 'dark',
  level = 2,
  style,
  children,
  ...rest
}) {
  const H = 'h' + level;
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      textAlign: align,
      maxWidth: align === 'center' ? '46rem' : undefined,
      marginInline: align === 'center' ? 'auto' : undefined,
      marginBottom: 'var(--space-6)',
      ...style
    }
  }, rest), eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: dark ? 'var(--text-muted)' : 'var(--iy-sage-200)',
      marginBottom: 'var(--space-3)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement(H, {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--step-5)',
      lineHeight: 'var(--lh-heading)',
      letterSpacing: 'var(--ls-heading)',
      margin: 0,
      color: dark ? 'var(--text-primary)' : 'var(--iy-cream-100)'
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--step-2)',
      lineHeight: 'var(--lh-snug)',
      maxWidth: 'var(--measure-lead)',
      marginInline: align === 'center' ? 'auto' : undefined,
      marginTop: 'var(--space-4)',
      marginBottom: 0,
      color: dark ? 'var(--text-body)' : 'var(--iy-cream-100)'
    }
  }, lead), children);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/StarIcon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Wraps the extracted brand star so consumers never re-crop the PNG. */
function StarIcon({
  size = 24,
  tone = 'black',
  spin = false,
  style,
  ...rest
}) {
  const src = tone === 'cream' ? 'icon-star-cream.png' : 'icon-star-black.png';
  const base = typeof window !== 'undefined' && window.IY_ASSET_BASE || '../../assets/';
  return /*#__PURE__*/React.createElement("img", _extends({
    src: base + src,
    alt: "",
    width: size,
    height: size,
    "aria-hidden": "true",
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      objectFit: 'contain',
      animation: spin ? 'iy-star-spin 9s linear infinite' : undefined,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { StarIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StarIcon.jsx", error: String((e && e.message) || e) }); }

// components/core/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatBlock({
  value,
  label,
  note,
  tone = 'dark',
  align = 'left',
  style,
  ...rest
}) {
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--step-6)',
      lineHeight: 1,
      letterSpacing: 'var(--ls-display)',
      color: dark ? 'var(--iy-teal-900)' : 'var(--iy-yellow-400)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step-0)',
      fontWeight: 700,
      marginTop: 'var(--space-3)',
      color: dark ? 'var(--text-primary)' : 'var(--iy-cream-100)'
    }
  }, label), note && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      marginTop: 'var(--space-2)',
      color: dark ? 'var(--text-muted)' : 'var(--iy-sage-200)'
    }
  }, note));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Disclosure.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Disclosure({
  items = [],
  defaultOpen = null,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderTop: '1.5px solid var(--iy-cream-200)',
      ...style
    }
  }, rest), items.map((it, i) => {
    const on = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: it.q,
      style: {
        borderBottom: '1.5px solid var(--iy-cream-200)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpen(on ? null : i),
      "aria-expanded": on,
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 'var(--space-4)',
        background: 'transparent',
        border: 0,
        cursor: 'pointer',
        padding: 'var(--space-5) 0',
        textAlign: 'left',
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 'var(--step-3)',
        color: 'var(--text-primary)'
      }
    }, /*#__PURE__*/React.createElement("span", null, it.q), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: '0 0 auto',
        width: 28,
        height: 28,
        borderRadius: '999px',
        border: '1.5px solid var(--iy-teal-900)',
        display: 'grid',
        placeItems: 'center',
        transform: on ? 'rotate(45deg)' : 'none',
        transition: 'transform var(--dur-base) var(--ease-standard)',
        fontFamily: 'var(--font-ui)',
        fontSize: 18,
        lineHeight: 1
      }
    }, "+")), /*#__PURE__*/React.createElement("div", {
      style: {
        maxHeight: on ? 400 : 0,
        overflow: 'hidden',
        transition: 'max-height var(--dur-slow) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--step-1)',
        margin: '0 0 var(--space-5)',
        maxWidth: 'var(--measure-body)'
      }
    }, it.a)));
  }));
}
Object.assign(__ds_scope, { Disclosure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Disclosure.jsx", error: String((e && e.message) || e) }); }

// components/forms/ChoiceField.jsx
try { (() => {
/** Checkbox / radio group drawn as tappable rows — the survey and application both use it. */
function ChoiceField({
  label,
  hint,
  name,
  type = 'radio',
  options = [],
  value,
  onChange,
  style
}) {
  const selected = Array.isArray(value) ? value : value == null ? [] : [value];
  const toggle = v => {
    if (!onChange) return;
    if (type === 'radio') return onChange(v);
    onChange(selected.includes(v) ? selected.filter(x => x !== v) : selected.concat([v]));
  };
  return /*#__PURE__*/React.createElement("fieldset", {
    style: {
      border: 0,
      padding: 0,
      margin: '0 0 var(--space-5)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("legend", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      padding: 0,
      marginBottom: 'var(--space-3)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, options.map(o => {
    const val = typeof o === 'string' ? o : o.value;
    const lab = typeof o === 'string' ? o : o.label;
    const on = selected.includes(val);
    return /*#__PURE__*/React.createElement("label", {
      key: val,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        fontFamily: 'var(--font-ui)',
        fontSize: 'var(--step-0)',
        color: 'var(--text-body)',
        background: on ? 'var(--iy-cream-100)' : 'var(--surface-card)',
        border: '1.5px solid ' + (on ? 'var(--iy-teal-900)' : 'var(--iy-cream-200)'),
        borderRadius: 'var(--radius-md)',
        padding: '12px 14px',
        cursor: 'pointer',
        transition: 'background-color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: type,
      name: name,
      checked: on,
      onChange: () => toggle(val),
      style: {
        appearance: 'none',
        width: 18,
        height: 18,
        margin: 0,
        flex: '0 0 auto',
        border: '1.5px solid var(--iy-teal-900)',
        borderRadius: type === 'radio' ? '999px' : 'var(--radius-xs)',
        background: on ? 'var(--iy-teal-900)' : 'transparent',
        boxShadow: on ? 'inset 0 0 0 3px var(--surface-card)' : 'none',
        cursor: 'pointer'
      }
    }), /*#__PURE__*/React.createElement("span", null, lab));
  })), hint && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      marginTop: 'var(--space-2)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { ChoiceField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ChoiceField.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const field = {
  fontFamily: 'var(--font-ui)',
  fontSize: 'var(--step-0)',
  color: 'var(--text-body)',
  background: 'var(--surface-card)',
  border: '1.5px solid var(--iy-cream-200)',
  borderRadius: 'var(--radius-md)',
  padding: '12px 14px',
  width: '100%',
  outline: 'none',
  transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)'
};
function Input({
  label,
  hint,
  error,
  id,
  required = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || 'iy-' + (label || 'field').toString().toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-5)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      display: 'block',
      marginBottom: 'var(--space-2)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--iy-sage-600)'
    }
  }, " *")), /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...field,
      borderColor: error ? 'var(--iy-plum-800)' : focus ? 'var(--iy-teal-900)' : 'var(--iy-cream-200)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none'
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      marginTop: 'var(--space-2)',
      color: error ? 'var(--iy-plum-800)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  error,
  id,
  options = [],
  placeholder = 'Choose one',
  required = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || 'iy-' + (label || 'select').toString().toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-5)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      display: 'block',
      marginBottom: 'var(--space-2)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--iy-sage-600)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fid,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step-0)',
      color: 'var(--text-body)',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 40px 12px 14px',
      width: '100%',
      outline: 'none',
      appearance: 'none',
      border: '1.5px solid ' + (error ? 'var(--iy-plum-800)' : focus ? 'var(--iy-teal-900)' : 'var(--iy-cream-200)'),
      boxShadow: focus ? 'var(--focus-ring)' : 'none'
    }
  }, rest), /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const val = typeof o === 'string' ? o : o.value;
    const lab = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lab);
  })), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    style: {
      position: 'absolute',
      right: 14,
      top: '50%',
      transform: 'translateY(-50%)',
      width: 18,
      height: 18,
      color: 'var(--iy-teal-900)',
      pointerEvents: 'none'
    }
  })), (hint || error) && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      marginTop: 'var(--space-2)',
      color: error ? 'var(--iy-plum-800)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/StepIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StepIndicator({
  steps = [],
  current = 0,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ol", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      listStyle: 'none',
      margin: 0,
      padding: 0,
      flexWrap: 'wrap',
      ...style
    }
  }, rest), steps.map((s, i) => {
    const done = i < current,
      now = i === current;
    return /*#__PURE__*/React.createElement("li", {
      key: s,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 'var(--space-2)',
        fontFamily: 'var(--font-ui)',
        fontSize: 'var(--step--1)',
        fontWeight: 700,
        letterSpacing: '.04em',
        textTransform: 'uppercase',
        color: now ? 'var(--iy-teal-900)' : done ? 'var(--iy-sage-600)' : 'var(--iy-char-400)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 24,
        height: 24,
        borderRadius: '999px',
        display: 'grid',
        placeItems: 'center',
        fontSize: 12,
        letterSpacing: 0,
        background: now ? 'var(--iy-teal-900)' : done ? 'var(--iy-sage-400)' : 'transparent',
        color: now ? 'var(--iy-cream-100)' : done ? 'var(--iy-teal-900)' : 'var(--iy-char-400)',
        border: '1.5px solid ' + (now ? 'var(--iy-teal-900)' : done ? 'var(--iy-sage-400)' : 'var(--iy-cream-200)')
      }
    }, done ? '\u2713' : i + 1), s), i < steps.length - 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 28,
        height: 1.5,
        background: done ? 'var(--iy-sage-400)' : 'var(--iy-cream-200)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { StepIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/StepIndicator.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label,
  hint,
  error,
  id,
  rows = 5,
  required = false,
  maxLength,
  value,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || 'iy-' + (label || 'field').toString().toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-5)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--text-primary)',
      display: 'block',
      marginBottom: 'var(--space-2)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--iy-sage-600)'
    }
  }, " *")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: fid,
    rows: rows,
    required: required,
    maxLength: maxLength,
    value: value,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step-0)',
      lineHeight: 1.55,
      color: 'var(--text-body)',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 14px',
      width: '100%',
      outline: 'none',
      resize: 'vertical',
      border: '1.5px solid ' + (error ? 'var(--iy-plum-800)' : focus ? 'var(--iy-teal-900)' : 'var(--iy-cream-200)'),
      boxShadow: focus ? 'var(--focus-ring)' : 'none'
    }
  }, rest)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      marginTop: 'var(--space-2)',
      color: error ? 'var(--iy-plum-800)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, error || hint), maxLength && /*#__PURE__*/React.createElement("span", null, value ? String(value).length : 0, "/", maxLength)));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteFooter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteFooter({
  columns = [],
  note,
  onNavigate,
  style,
  ...rest
}) {
  const base = typeof window !== 'undefined' && window.IY_ASSET_BASE || '../../assets/';
  return /*#__PURE__*/React.createElement("footer", _extends({
    style: {
      background: 'var(--iy-teal-900)',
      color: 'var(--iy-cream-100)',
      padding: 'var(--space-8) 0 var(--space-6)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--container-pad)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-8)',
      flexWrap: 'wrap',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 260px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: base + 'logo-stacked-cream.png',
    alt: "Independently Yours",
    style: {
      height: 74,
      display: 'block'
    }
  })), columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title,
    style: {
      flex: '0 0 auto',
      minWidth: 150
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--iy-sage-200)',
      marginBottom: 'var(--space-3)'
    }
  }, col.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, col.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l.label
  }, /*#__PURE__*/React.createElement("a", {
    href: l.href || (l.id ? '#' + l.id : '#'),
    target: l.href && !l.href.startsWith('mailto:') ? '_blank' : undefined,
    rel: l.href ? 'noopener' : undefined,
    onClick: e => {
      if (!l.href && l.id && onNavigate) {
        e.preventDefault();
        onNavigate(l.id);
      }
    },
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step-0)',
      color: 'var(--iy-cream-100)',
      textDecoration: 'none'
    }
  }, l.label))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      borderTop: '1px solid rgba(242,231,215,.2)',
      marginTop: 'var(--space-7)',
      paddingTop: 'var(--space-4)',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      color: 'var(--iy-sage-200)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StarIcon, {
    size: 14,
    tone: "cream"
  }), /*#__PURE__*/React.createElement("span", null, note))));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteHeader({
  items = [],
  active,
  onNavigate,
  cta = 'Apply',
  ctaCompact = 'Apply',
  onCta,
  tone = 'cream',
  style,
  ...rest
}) {
  const base = typeof window !== 'undefined' && window.IY_ASSET_BASE || '../../assets/';
  const dark = tone === 'teal';
  const [tight, setTight] = React.useState(typeof window !== 'undefined' && window.innerWidth < 1040);
  React.useEffect(() => {
    const on = () => setTight(window.innerWidth < 1040);
    window.addEventListener('resize', on);
    on();
    return () => window.removeEventListener('resize', on);
  }, []);
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: dark ? 'var(--iy-teal-900)' : 'var(--surface-page)',
      borderBottom: '1.5px solid ' + (dark ? 'rgba(242,231,215,.2)' : 'var(--line-hairline)'),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--space-4) var(--container-pad)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)',
      flexWrap: 'wrap',
      rowGap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#home",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(items[0] && items[0].id);
    },
    style: {
      display: 'block',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: base + (dark ? 'logo-horizontal-cream.png' : 'logo-horizontal-black.png'),
    alt: "Independently Yours",
    style: {
      height: tight ? 20 : 26,
      maxWidth: '100%',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'clamp(var(--space-3),2vw,var(--space-5))',
      marginLeft: 'auto',
      alignItems: 'center',
      flexWrap: 'wrap',
      justifyContent: 'flex-end',
      minWidth: 0,
      rowGap: 'var(--space-3)'
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: it.href || '#' + it.id,
    target: it.href ? '_blank' : undefined,
    rel: it.href ? 'noopener' : undefined,
    onClick: e => {
      if (it.href) return;
      e.preventDefault();
      onNavigate && onNavigate(it.id);
    },
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: tight ? 'var(--step--1)' : 'var(--step-0)',
      fontWeight: active === it.id ? 700 : 600,
      textDecoration: 'none',
      whiteSpace: 'nowrap',
      paddingBottom: 2,
      borderBottom: '2px solid ' + (active === it.id ? 'var(--iy-sage-600)' : 'transparent'),
      color: dark ? 'var(--iy-cream-100)' : 'var(--text-primary)'
    }
  }, it.label)), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    variant: dark ? 'inverse' : 'primary',
    onClick: onCta
  }, tight ? ctaCompact : cta))));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AboutScreen.jsx
try { (() => {
const {
  Button: AboutButton,
  Badge: AboutBadge,
  PatternPanel: AboutPattern,
  SectionHeading: AboutHeading
} = window.IndependentlyYoursDesignSystem_da5bbe;
const ABOUT_PILLARS = ['Community', 'Education', 'Data'];
function AboutScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(AboutBadge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "About"), /*#__PURE__*/React.createElement("h1", {
    style: {
      maxWidth: '20ch',
      margin: '0 0 var(--space-5)',
      fontSize: 'clamp(var(--step-4), 4.6vw, var(--step-6))'
    }
  }, "Built to put artists first"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-1)',
      maxWidth: '64ch',
      lineHeight: 1.6,
      textWrap: 'pretty'
    }
  }, "Independently Yours is a platform and community built to put artists first\u2014offering education, workshops, and mentorship, while delivering biannual consumer insights grounded in real fan data. It creates spaces for connection through events, showcases, and both digital and real-world communities. By doing so, it empowers artists, fans, and industry allies to come together with the shared mission of shifting the music industry\u2014making independence not just possible, but a powerful and intentional choice, driven by community, data, and artist-led values."))), /*#__PURE__*/React.createElement(AboutPattern, {
    tone: "teal",
    hasCopy: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap band",
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.2fr)',
      gap: 'var(--space-8)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      color: 'var(--iy-cream-100)',
      fontSize: 'clamp(var(--step-4), 4vw, var(--step-6))'
    }
  }, "It\u2019s a movement."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-cream-100)',
      fontSize: 'var(--step-2)',
      lineHeight: 1.5,
      margin: '0 0 var(--space-6)',
      textWrap: 'pretty'
    }
  }, "By helping artists grow their careers on their own terms, we aim to redefine success in the music industry. Our growth strategy prioritizes community, education, and data as the foundation of long-term sustainability."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-3)'
    }
  }, ABOUT_PILLARS.map(p => /*#__PURE__*/React.createElement("span", {
    key: p,
    style: {
      border: '1.5px solid var(--iy-sage-400)',
      color: 'var(--iy-cream-100)',
      borderRadius: 'var(--radius-pill)',
      padding: '8px 18px',
      fontSize: 'var(--step-0)',
      fontWeight: 700
    }
  }, p)))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-8)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      flex: '0 1 320px',
      minWidth: 220
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: (window.IY_ASSET_BASE || '../../assets/') + 'kristin-juel-web.jpg',
    alt: "Kristin Juel seated on a Vox amp against an orange backdrop",
    style: {
      display: 'block',
      width: '100%',
      aspectRatio: '4 / 5',
      objectFit: 'cover',
      objectPosition: '50% 30%',
      borderRadius: 'var(--radius-md)'
    }
  }), /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: 'var(--space-2)',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      color: 'var(--text-muted)'
    }
  }, "Photo: Elaine Torres")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 420px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "iy-eyebrow",
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "Meet the Founder"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 var(--space-2)',
      fontSize: 'clamp(var(--step-4), 4vw, var(--step-5))'
    }
  }, "Kristin Juel"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 var(--space-6)',
      fontSize: 'var(--step-1)',
      fontWeight: 700,
      color: 'var(--iy-sage-600)'
    }
  }, "Founder/President & Executive Director"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      maxWidth: '64ch',
      textWrap: 'pretty'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Kristin Juel is the founder of both Independently Yours (501c3 established in 2026) and Juel Concepts, a music marketing and management firm established in 2013, which applies her two decades of brand-building experience (e.g., Nissan, KFC, Kaiser Permanente) to empower independent artists for the data-driven industry. Her work, guided by tenets of passionate, proactive, and transparent service, has helped elevate artists like Hamish Anderson and Shelly Peiken."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Additionally, Kristin was a Senior Analyst for Water & Music, specializing in AI music, Web3, and the metaverse, and she actively supports the industry as a Governor on the LA Chapter of the Recording Academy, an advisor to startups and through mentorship with organizations like Grammy U."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "She has rewritten the curriculum and is teaching the Music Business Marketing Courses at Musician\u2019s Institute and the DIY Artist Marketing Course at UCLA\u2019s Luskin School."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Kristin resides in Los Angeles, where she is an avid member of the live-music-rocks-any-night-of-the-week club."))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(AboutHeading, {
    eyebrow: "Next",
    title: "Mission and Vision"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(AboutButton, {
    onClick: () => go('mission')
  }, "Read our mission"), /*#__PURE__*/React.createElement(AboutButton, {
    variant: "secondary",
    onClick: () => go('program')
  }, "See the program")))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AboutScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ApplyScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  StarIcon,
  PatternPanel,
  SectionHeading,
  Disclosure
} = window.IndependentlyYoursDesignSystem_da5bbe;
const APPLY_NEEDS = ['Your artist or project name as it appears on streaming.', 'Links to your work', 'A rough sense of what you earned from music last year. Ranges are fine.', 'Two or three sentences on what you want to achieve by the end of the twelve weeks.'];
const APPLY_ELIGIBLE = ["You've released work already — any scale, any genre. NOTE: we are not considering AI projects this time.", 'You handle your own business, or want to. You desire autonomy and to lead a team to achieve your vision.', 'You can commit to all 8 weekly sessions, the networking mixer, and any assessment meetings in the last 4 weeks.', 'The first program takes place in LA. If you live outside of LA, you can still apply, and we will hold your application for 12 months to attend future programs.'];
const APPLY_NEXT = [{
  n: '1',
  t: 'We read everything after the deadline',
  d: "Not as they arrive, so applying early doesn't help you and applying late doesn't work at all."
}, {
  n: '2',
  t: 'You might get a short call',
  d: "If you're being considered, we may reach out for a short call."
}, {
  n: '3',
  t: 'Selected artists hear by mid December',
  d: 'You will only be notified upon selection, by mid December 2026.'
}];
const APPLY_FAQ = [{
  q: 'Can I edit my answers after submitting?',
  a: "No. Answers can't be edited once submitted, so review everything before you send it."
}, {
  q: 'Do I need a manager or a lawyer?',
  a: "No. That's most of the point."
}, {
  q: 'Does it cost anything to apply?',
  a: 'No, and with ongoing donations, it never will.'
}, {
  q: 'What if I miss the deadline?',
  a: 'The deadline is for the first cohort in 2027. We keep applications for 12 months for consideration in following cohorts.'
}];
function ApplyScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "cream",
    hasCopy: true,
    tile: 300
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-tight) var(--container-pad)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "First cohort \xB7 15 artists \xB7 2027"), /*#__PURE__*/React.createElement("h1", {
    style: {
      maxWidth: '22ch',
      margin: '0 0 var(--space-5)',
      fontSize: 'clamp(var(--step-4), 4.6vw, var(--step-6))'
    }
  }, "One application, one community survey, no fees"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-2)',
      maxWidth: '52ch',
      margin: 0
    }
  }, "Applications close 5 November 2026. Read the two lists below first, they'll save you a rewrite."))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-5)'
    }
  }, [['What you\u2019ll need', APPLY_NEEDS], ['Who can apply', APPLY_ELIGIBLE]].map(([title, items]) => /*#__PURE__*/React.createElement(Card, {
    key: title,
    variant: "drawn",
    tone: "white"
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '0 0 var(--space-4)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, items.map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(StarIcon, {
    size: 16,
    style: {
      flex: '0 0 auto',
      marginTop: 4
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-0)'
    }
  }, i)))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "The application",
    title: "Before you start",
    lead: "Submit once. Answers can't be edited after you submit."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      maxWidth: '60ch'
    }
  }, "Your application includes a short survey to share with your fans and collaborators. Their responses carry real weight in our review - 25% worth."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application")))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-sage-400)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "What happens next",
    title: "The Path Ahead"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-5)'
    }
  }, APPLY_NEXT.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.n,
    variant: "drawn",
    tone: "white"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, s.n), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '0 0 var(--space-3)'
    }
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-0)',
      margin: 0
    }
  }, s.d)))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Application FAQ",
    title: "Before you ask"
  }), /*#__PURE__*/React.createElement(Disclosure, {
    items: APPLY_FAQ,
    defaultOpen: 0
  }))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ApplyScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  StarIcon,
  PatternPanel,
  SectionHeading,
  StatBlock
} = window.IndependentlyYoursDesignSystem_da5bbe;
function HomeScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "teal",
    hasCopy: true,
    tile: 300
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: '96px var(--container-pad) 104px',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.15fr) minmax(0,.85fr)',
      gap: 'var(--space-8)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "First cohort \xB7 2027 \xB7 applications open"), /*#__PURE__*/React.createElement("h1", {
    style: {
      color: 'var(--iy-cream-100)',
      fontSize: 'clamp(var(--step-5), 5.4vw, var(--step-7))',
      margin: '0 0 var(--space-6)'
    }
  }, "Activating Independence as a Strategy"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "pulse",
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "inverse-outline",
    onClick: () => go('program')
  }, "See the program"))), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-cream-100)',
      fontSize: 'var(--step-2)',
      maxWidth: '42ch',
      margin: 0,
      lineHeight: 1.55
    }
  }, "Independently Yours is a nonprofit built on a simple idea: Independence does not mean alone, but it does require business acumen.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "Cohort style: Twelve weeks, fifteen artists, and a room of people who have done the work dedicated to you each week."))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Curriculum",
    title: "Program & Workshops",
    lead: "The twelve-week curriculum will be created bespokely for those in the room and will be shared with the selected applicants."
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go('program')
  }, "See the program"))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-sage-400)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(150px, 100%), 1fr))',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(StatBlock, {
    value: "12",
    label: "weeks, start to finish",
    note: "8 weekly sessions + 4 weeks of assessments \xB7 Tentatively Thursdays 1-4 pm"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "15",
    label: "artists in the first cohort",
    note: "Selected Applicants will hear by mid December, 2026"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "2027",
    label: "first cohort year",
    note: "Applications close 5 November 2026"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "$0",
    label: "cost to accepted artists"
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-8)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Research",
    title: "The Indie Pulse Index",
    lead: "We ask independent artists and fans what they really know about being indie, music discovery and fandom."
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-1)'
    }
  }, "Wave one is in field now. Add your thoughts."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "pulse",
    href: "https://bit.ly/IPIEVERFAN",
    target: "_blank",
    rel: "noopener"
  }, "Take the fan survey"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go('pulse')
  }, "About the Index"))), /*#__PURE__*/React.createElement(Card, {
    variant: "floated",
    tone: "white",
    style: {
      borderTop: '6px solid var(--iy-yellow-400)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "iy-eyebrow",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "Wave 1 \xB7 in field"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-1)'
    }
  }, "The Indie Pulse Index is bi-annual and free to the public. The first report follows once wave one closes."))))), /*#__PURE__*/React.createElement("section", {
    className: "band",
    style: {
      borderTop: '1.5px solid var(--iy-cream-200)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "iy-eyebrow",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "With gratitude to our lead sponsor"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'clamp(var(--step-4), 4vw, var(--step-5))',
      fontWeight: 700,
      letterSpacing: '.12em',
      color: 'var(--iy-teal-900)',
      margin: '0 0 var(--space-5)'
    }
  }, "CY LEE"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 auto',
      maxWidth: '56ch',
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      textWrap: 'pretty'
    }
  }, "Independently Yours is made possible in part through the generous support of CY Lee. His patronage for artistry and culture helps make this program accessible to the artists who need it most."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    href: "https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser",
    target: "_blank",
    rel: "noopener"
  }, "Donate to Independently Yours")))), /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "cream",
    hasCopy: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-tight) var(--container-pad)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 var(--space-4)',
      fontSize: 'clamp(var(--step-4), 4vw, var(--step-5))'
    }
  }, "Applications close 5 November 2026."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 auto var(--space-6)',
      maxWidth: '46ch',
      fontSize: 'var(--step-2)'
    }
  }, "One application, one community survey, no fees."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application"))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MissionScreen.jsx
try { (() => {
const {
  Button: MissionButton,
  Badge: MissionBadge,
  StarIcon: MissionStar,
  PatternPanel: MissionPattern,
  SectionHeading: MissionHeading
} = window.IndependentlyYoursDesignSystem_da5bbe;
const MISSION_WORKSHOPS = ['Marketing / Narrative / SWOT Fundamentals', 'Social / Content / Paid Ads', 'Media, PR & Visual Content', 'Sync Licensing', 'Publishing', 'Tech & Content Management', 'Music Business Fundamentals / Monetization', 'Touring & Live Business'];
function MissionScreen({
  go
}) {
  const eyebrow = {
    fontSize: 'var(--step--1)',
    fontWeight: 700,
    letterSpacing: '.16em',
    textTransform: 'uppercase',
    margin: '0 0 var(--space-4)'
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.1fr)',
      gap: 'var(--space-8)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(MissionBadge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "Mission"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 'clamp(var(--step-3), 3.6vw, var(--step-5))',
      lineHeight: 1.15,
      textWrap: 'pretty'
    }
  }, "To empower independent artists with education, mentorship, community, and industry opportunities.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      margin: 'var(--space-8) 0 0',
      textWrap: 'pretty'
    }
  }, "Our mission is to make independence not just possible\u2014but profitable and sustainable. We are building a new economic engine for artist freedom with a transparent infrastructure of mentorship, funding, and data\u2014empowering artists to control their own narratives without giving up their masters."))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(MissionHeading, {
    eyebrow: "Workshops",
    title: "What we teach"
  }), /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(min(210px, 100%), 1fr))',
      gap: 'var(--space-6) var(--space-5)'
    }
  }, MISSION_WORKSHOPS.map((w, i) => /*#__PURE__*/React.createElement("li", {
    key: w,
    style: {
      borderTop: '3px solid var(--iy-sage-400)',
      paddingTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--step--1)',
      color: 'var(--text-muted)',
      fontWeight: 700,
      marginBottom: 'var(--space-2)'
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--step-1)',
      fontWeight: 700,
      lineHeight: 1.3,
      color: 'var(--iy-teal-900)',
      textWrap: 'pretty'
    }
  }, w)))))), /*#__PURE__*/React.createElement(MissionPattern, {
    tone: "teal",
    hasCopy: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap band",
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.1fr)',
      gap: 'var(--space-8)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      ...eyebrow,
      color: 'var(--iy-sage-200)'
    }
  }, "Vision"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      color: 'var(--iy-cream-100)',
      fontSize: 'clamp(var(--step-3), 3.6vw, var(--step-5))',
      lineHeight: 1.15,
      textWrap: 'pretty'
    }
  }, "To be the leading resource and accelerator for indie music creators, bridging the gap between artistry, business, and community impact.")), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-cream-100)',
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      margin: 'var(--space-8) 0 0',
      textWrap: 'pretty'
    }
  }, "We are building a music industry where the 0.1% who break through becomes the many \u2014 where artistic independence is the most competitive, most sustainable, and most sought-after path in music. A world where artists never have to choose between their art and their autonomy.")), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      paddingBottom: 'var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid rgba(242,231,215,.3)',
      paddingTop: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--iy-cream-100)',
      fontSize: 'clamp(var(--step-3), 3.4vw, var(--step-5))',
      lineHeight: 1.2
    }
  }, "Where independence isn't just an option.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--iy-yellow-400)',
      fontWeight: 700
    }
  }, "It's THE choice."))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(MissionStar, {
    size: 18
  }), /*#__PURE__*/React.createElement(MissionButton, {
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application"), /*#__PURE__*/React.createElement(MissionButton, {
    variant: "secondary",
    onClick: () => go('program')
  }, "See the program"))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MissionScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProgramScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  StarIcon,
  PatternPanel,
  SectionHeading,
  Disclosure
} = window.IndependentlyYoursDesignSystem_da5bbe;
const PROGRAM_WORKSHOPS = ['Marketing / Narrative / SWOT Fundamentals', 'Social / Content / Paid Ads', 'Media, PR & Visual Content', 'Sync Licensing', 'Publishing', 'Tech & Content Management', 'Music Business Fundamentals / Monetization', 'Touring & Live Business'];
const PROGRAM_EXTRAS = ['Infrastructure Audit', 'Networking Opportunities'];
const PROGRAM_FOR = ['Independent, with no meaningful label development behind them, roughly 3+ years in', 'Releasing consistently, with a body of work and a clear point of view', 'Real fans who show up (live shows, email/SMS, Discord, Patreon, Bandcamp): people who do something, not just listen', "Some validation (sync, playlists, press, festivals), but music income isn't sustainable yet", 'Coachable and reliable, ready to activate a release or campaign during the cohort, and willing to share baseline data', 'Any genre, with LA as the location for the first program. We especially want voices from communities the traditional industry tends to overlook. If they live outside of LA, they can still apply, and we will hold them for future programs.', 'At this time, we are not accepting AI music projects.'];
const PROGRAM_NOT_YET = ['Artists with no releases or audience yet', 'Established artists looking for a one-time publicity bump', 'Anyone expecting guaranteed funding, placements, or a deal', 'Anyone whose whole strategy hinges on going viral'];
const PROGRAM_FAQ = [{
  q: 'Does it cost anything to apply?',
  a: 'No, and with ongoing donations, it never will.'
}, {
  q: 'Do I need a manager or a lawyer?',
  a: "No. That's most of the point."
}, {
  q: 'Can I edit my answers after submitting?',
  a: "No. Answers can't be edited once submitted, so review everything before you send it."
}, {
  q: 'What if I miss the deadline?',
  a: 'The deadline is for the first cohort in 2027. We keep applications for 12 months for consideration in following cohorts.'
}, {
  q: 'What does it cost?',
  a: 'Nothing. The program is free for selected applicants.'
}, {
  q: 'What is expected of me?',
  a: 'Attendance at all 8 weekly sessions, the networking mixer, plus any assessment meetings during the last 4 weeks of the program.'
}, {
  q: 'Where does the program take place?',
  a: 'LA is the location for the first program. We especially want voices from communities the traditional industry tends to overlook. If applicants live outside of LA, they can still apply, and we will hold them for future programs.'
}, {
  q: 'What genres do you accept?',
  a: 'All genres are welcome. At this time, we are not accepting AI music projects.'
}];
function ProgramScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "First cohort \xB7 2027"), /*#__PURE__*/React.createElement("h1", {
    style: {
      maxWidth: '22ch',
      margin: '0 0 var(--space-5)',
      fontSize: 'clamp(var(--step-4), 4.6vw, var(--step-6))'
    }
  }, "The program, in plain terms"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-2)',
      maxWidth: '52ch'
    }
  }, "Twelve weeks of business practice for independent artists: what you own, what it earns, and how you run it next year without a label doing it for you."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      marginTop: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => go('pulse')
  }, "See the research")))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Curriculum",
    title: "Program & Workshops",
    lead: "The twelve-week curriculum will be created bespokely for those in the room and will be shared with the selected applicants prior to the start of the program."
  }), /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(min(210px, 100%), 1fr))',
      gap: 'var(--space-6) var(--space-5)'
    }
  }, PROGRAM_WORKSHOPS.map((w, i) => /*#__PURE__*/React.createElement("li", {
    key: w,
    style: {
      borderTop: '3px solid var(--iy-sage-400)',
      paddingTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--step--1)',
      color: 'var(--text-muted)',
      fontWeight: 700,
      marginBottom: 'var(--space-2)'
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--step-1)',
      fontWeight: 700,
      lineHeight: 1.3,
      color: 'var(--iy-teal-900)',
      textWrap: 'pretty'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-7)',
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "iy-eyebrow"
  }, "Plus"), PROGRAM_EXTRAS.map(x => /*#__PURE__*/React.createElement(Card, {
    key: x,
    variant: "drawn",
    tone: "cream",
    style: {
      padding: 'var(--space-4) var(--space-5)',
      fontSize: 'var(--step-1)',
      fontWeight: 700,
      color: 'var(--iy-teal-900)'
    }
  }, x))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-cream-100)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Who this is for",
    title: "Audience-ready, but needs system infrastructure"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(320px, 100%), 1fr))',
      gap: 'var(--space-5)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "drawn",
    tone: "white"
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '0 0 var(--space-4)'
    }
  }, "A good fit"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, PROGRAM_FOR.map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(StarIcon, {
    size: 16,
    style: {
      flex: '0 0 auto',
      marginTop: 4
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-0)',
      textWrap: 'pretty'
    }
  }, i)))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'var(--space-5) 0 0',
      paddingTop: 'var(--space-4)',
      borderTop: '1.5px solid var(--iy-cream-200)',
      fontSize: 'var(--step-0)',
      fontStyle: 'italic'
    }
  }, "As a gut check, 10K\u201375K monthly listeners is a helpful signal, not a requirement.")), /*#__PURE__*/React.createElement(Card, {
    variant: "drawn",
    tone: "cream"
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '0 0 var(--space-4)'
    }
  }, "Probably not the right fit (yet)"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      paddingLeft: '1.1em',
      display: 'grid',
      gap: 'var(--space-3)',
      fontSize: 'var(--step-0)'
    }
  }, PROGRAM_NOT_YET.map(i => /*#__PURE__*/React.createElement("li", {
    key: i
  }, i))))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'var(--space-7) 0 0',
      maxWidth: '48ch',
      fontSize: 'var(--step-2)',
      lineHeight: 1.4,
      color: 'var(--iy-teal-900)',
      textWrap: 'pretty'
    }
  }, "Our favorite shorthand: proof of promise, proof of effort, and proof of audience, but not yet proof of a repeatable business model."))), /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "teal",
    hasCopy: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap band"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '60rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    tone: "light",
    eyebrow: "How it runs",
    title: "TENTATIVELY - Thursdays from 1-4 pm in Hollywood, CA",
    lead: "Short Lectures, Discussions, Panels, Workshops and Real Talk."
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-cream-100)',
      fontSize: 'var(--step-1)'
    }
  }, "8 weekly sessions, then 4 weeks of assessments. Fifteen artists in the room so every session can look at your real pain points. The date, time, session length and location are tentative til January 2027."), /*#__PURE__*/React.createElement("div", {
    className: "iy-accent",
    style: {
      color: 'var(--iy-yellow-400)',
      marginTop: 'var(--space-4)'
    }
  }, "In 12 weeks, you'll build business acumen to reign supreme as the CEO of your own empire.")))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Questions",
    title: "Before you apply"
  }), /*#__PURE__*/React.createElement(Disclosure, {
    items: PROGRAM_FAQ,
    defaultOpen: 0
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      marginTop: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement(StarIcon, {
    size: 18
  }), /*#__PURE__*/React.createElement(Button, {
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application")))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProgramScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PulseScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  PatternPanel,
  SectionHeading,
  ChoiceField,
  Disclosure
} = window.IndependentlyYoursDesignSystem_da5bbe;
function PulseScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "pulse",
    hasCopy: true,
    tile: 260
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-tight) var(--container-pad)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "Wave 1 \xB7 in field"), /*#__PURE__*/React.createElement("h1", {
    style: {
      color: 'var(--iy-espresso-900)',
      maxWidth: '26ch',
      margin: '0 0 var(--space-5)',
      fontWeight: 700,
      fontSize: 'clamp(var(--step-4), 4.6vw, var(--step-6))'
    }
  }, "The Indie Pulse Index"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-espresso-900)',
      fontSize: 'var(--step-2)',
      maxWidth: '50ch'
    }
  }, "What do artists and fans really know about being indie, music discovery and fandom? We're asking both. Wave one is in field now \u2014 add your thoughts."))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.3fr)',
      gap: 'var(--space-8)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "About the Index",
    title: "The research arm of Independently Yours"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      fontSize: 'var(--step-1)',
      lineHeight: 1.6,
      textWrap: 'pretty'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Independently Yours also operates as the data collector of the ecosystem, feeding valuable, real-time data into the research arm - The Indie Pulse. Independently Yours provides insights from data generated by the artist development & fan base pipelines."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "By developing a proprietary understanding of fan behavior this enables the \"The Indie Pulse Index\", a bi-annual industry trend research that positions Independently Yours as a true Industry Resource. ", /*#__PURE__*/React.createElement("strong", null, "The Indie Pulse Index research will be provided to the public as an academic reference for everyone - for free.")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      paddingLeft: 'var(--space-5)',
      borderLeft: '4px solid var(--iy-yellow-400)'
    }
  }, "This service directly addresses the industry's critical need for real time, market intelligence, simultaneously de-risking the label environment and attracting essential sponsorships for the nonprofit's mission.")))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-pulse-soft)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Take the survey",
    title: "Add your thoughts",
    lead: /*#__PURE__*/React.createElement(React.Fragment, null, "Short Google Forms.", /*#__PURE__*/React.createElement("br", null), "Represent from your own experiences!")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(min(260px, 100%), 1fr))',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "floated",
    tone: "white",
    style: {
      borderTop: '6px solid var(--iy-yellow-400)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "Open now"), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--step-3)'
    }
  }, "For fans"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-1)'
    }
  }, "How you find independent artists, and what being a fan looks like for you."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "pulse",
    href: "https://bit.ly/IPIEVERFAN",
    target: "_blank",
    rel: "noopener",
    style: {
      whiteSpace: 'normal',
      textAlign: 'center',
      maxWidth: '100%'
    }
  }, "Take the fan survey")), /*#__PURE__*/React.createElement(Card, {
    variant: "drawn",
    tone: "cream",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal"
  }, "Coming soon"), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--step-3)'
    }
  }, "For artists"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-1)'
    }
  }, "A survey for independent artists opens later."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    disabled: true,
    style: {
      whiteSpace: 'normal',
      textAlign: 'center',
      maxWidth: '100%'
    }
  }, "Artist survey coming soon"))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Fine print",
    title: "How we handle your answers"
  }), /*#__PURE__*/React.createElement(Disclosure, {
    items: [{
      q: 'Is it anonymous?',
      a: 'Yes. Responses are collected in Google Forms and stored in Google Drive.'
    }, {
      q: 'Who sees the raw data?',
      a: 'Only the Independently Yours administration and its research partners will have access to raw data from responses.'
    }, {
      q: 'Can I get the report?',
      a: "Yes. The report publishes bi-annually, free for everyone. No paywall, no signup."
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Apply to the cohort")))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PulseScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ResourcesScreen.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  StarIcon,
  PatternPanel,
  SectionHeading,
  Disclosure
} = window.IndependentlyYoursDesignSystem_da5bbe;
const RES_CATEGORIES = ['All', 'Ownership', 'Money', 'Touring', 'Releasing', 'Contracts'];
const RES_FILES = [{
  t: 'Split sheet',
  c: 'Ownership',
  k: 'PDF',
  d: 'Who wrote what, in what percentage, signed in the room before anyone leaves.'
}, {
  t: 'Metadata template',
  c: 'Releasing',
  k: 'Sheet',
  d: 'Every field a distributor asks for, in the order they ask for it.'
}, {
  t: 'Tour advance sheet',
  c: 'Touring',
  k: 'PDF',
  d: 'What to confirm with the promoter before you get in the van.'
}, {
  t: 'Release budget worksheet',
  c: 'Money',
  k: 'Sheet',
  d: 'What a single actually costs you, line by line.'
}, {
  t: 'Contractor agreement checklist',
  c: 'Contracts',
  k: 'Doc',
  d: 'What has to be in writing before a mixer, designer or player starts.'
}, {
  t: 'Invoice template',
  c: 'Money',
  k: 'Sheet',
  d: 'For session work, features, and getting paid on time.'
}, {
  t: 'Release timeline',
  c: 'Releasing',
  k: 'Sheet',
  d: 'Eight weeks out to release day, backwards.'
}, {
  t: 'Day-of-show settlement sheet',
  c: 'Touring',
  k: 'PDF',
  d: 'Count the door with the same numbers the promoter is using.'
}];
const RES_STEPS = ['Make your own copy.', 'Fill it in before the session, the studio date, or the show — not after.', 'Keep it somewhere your collaborators can actually find it.'];
const RES_TERMS = [{
  q: 'Can I use these commercially?',
  a: 'Yes. They\u2019re yours to use on your own projects.'
}, {
  q: 'Is this legal advice?',
  a: 'No. These are templates for organizing your own work, not a substitute for a lawyer on a deal that matters.'
}, {
  q: 'Can I share them with my collaborators?',
  a: 'Yes. Send them this page rather than the file, so they get the current version.'
}];
function ResourcesScreen({
  go
}) {
  const [cat, setCat] = React.useState('All');
  const shown = cat === 'All' ? RES_FILES : RES_FILES.filter(r => r.c === cat);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "cream",
    hasCopy: true,
    tile: 300
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-tight) var(--container-pad)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "teal",
    style: {
      marginBottom: 'var(--space-5)'
    }
  }, "Free \xB7 no signup"), /*#__PURE__*/React.createElement("h1", {
    style: {
      maxWidth: '24ch',
      margin: '0 0 var(--space-5)',
      fontSize: 'clamp(var(--step-4), 4.6vw, var(--step-6))'
    }
  }, "The documents, free, whether you apply or not"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-2)',
      maxWidth: '52ch',
      margin: 0
    }
  }, "These are the same templates we use in the room. Take them, rename them, use them on your next release. We don't ask for your email first."))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-6)'
    }
  }, RES_CATEGORIES.map(c => {
    const on = c === cat;
    return /*#__PURE__*/React.createElement("button", {
      key: c,
      onClick: () => setCat(c),
      style: {
        fontFamily: 'var(--font-ui)',
        fontSize: 'var(--step--1)',
        fontWeight: 'var(--weight-bold)',
        padding: '8px 16px',
        borderRadius: 'var(--radius-pill)',
        cursor: 'pointer',
        background: on ? 'var(--iy-teal-900)' : 'transparent',
        color: on ? 'var(--text-inverse)' : 'var(--text-body)',
        border: '1.5px solid ' + (on ? 'var(--iy-teal-900)' : 'var(--iy-cream-200)'),
        transition: 'background-color var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)'
      }
    }, c);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-5)'
    }
  }, shown.map((r, i) => /*#__PURE__*/React.createElement(Card, {
    key: r.t,
    variant: "drawn",
    tone: i % 2 === 1 ? 'cream' : 'white'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      marginBottom: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "sage"
  }, r.k), /*#__PURE__*/React.createElement(Badge, {
    tone: "teal"
  }, r.c)), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '0 0 var(--space-3)'
    }
  }, r.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--step-0)',
      margin: '0 0 var(--space-5)'
    }
  }, r.d), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, r.k === 'Sheet' ? 'Copy sheet' : 'Download')))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--step--1)',
      color: 'var(--text-muted)',
      marginTop: 'var(--space-5)'
    }
  }, "Placeholder set \u2014 confirm which files exist today. \"Copy sheet\" opens a Google make-a-copy link so nobody edits the original."))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--iy-sage-400)'
    },
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-8)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "How to use these",
    title: "A template only works if you fill it in early"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, RES_STEPS.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(StarIcon, {
    size: 20
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--step-1)'
    }
  }, s)))))), /*#__PURE__*/React.createElement("section", {
    className: "band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      maxWidth: 'var(--container-narrow)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Terms of use",
    title: "What you can do with them"
  }), /*#__PURE__*/React.createElement(Disclosure, {
    items: RES_TERMS,
    defaultOpen: 0
  }))), /*#__PURE__*/React.createElement(PatternPanel, {
    tone: "teal",
    hasCopy: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      padding: 'var(--section-y-tight) var(--container-pad)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: 'var(--iy-cream-100)',
      margin: '0 0 var(--space-4)',
      fontSize: 'clamp(var(--step-4), 4vw, var(--step-5))'
    }
  }, "If the templates helped, the cohort goes further."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--iy-cream-100)',
      margin: '0 auto var(--space-6)',
      maxWidth: '46ch',
      fontSize: 'var(--step-2)'
    }
  }, "Fifteen artists, twelve weeks, starting 2027."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "inverse",
    href: "https://bit.ly/IYALPHAAPP",
    target: "_blank",
    rel: "noopener"
  }, "Start your application"))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ResourcesScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Site.jsx
try { (() => {
const {
  SiteHeader,
  SiteFooter
} = window.IndependentlyYoursDesignSystem_da5bbe;
const SITE_NAV = [{
  id: 'home',
  label: 'Home'
}, {
  id: 'about',
  label: 'About'
}, {
  id: 'mission',
  label: 'Mission'
}, {
  id: 'program',
  label: 'Program'
}, {
  id: 'pulse',
  label: 'Indie Pulse Index'
}, {
  id: 'donate',
  label: 'Donate',
  href: 'https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser'
}];
function Site() {
  const SITE_PAGES = ['home', 'about', 'mission', 'program', 'apply', 'pulse'];
  const fromHash = () => {
    const h = location.hash.slice(1);
    return SITE_PAGES.includes(h) ? h : 'home';
  };
  const [page, setPage] = React.useState(fromHash);
  React.useEffect(() => {
    const on = () => setPage(fromHash());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  React.useEffect(() => {
    window.scrollTo(0, 0);
    if (window.lucide) window.lucide.createIcons();
    (window.dataLayer = window.dataLayer || []).push({
      event: 'virtual_page_view',
      page_path: '/' + (page === 'home' ? '' : page),
      page_title: page
    });
  }, [page]);
  const go = id => {
    if (location.hash.slice(1) !== id) location.hash = id;
    setPage(id);
  };
  const Screen = {
    home: HomeScreen,
    program: ProgramScreen,
    apply: ApplyScreen,
    pulse: PulseScreen,
    about: AboutScreen,
    mission: MissionScreen
  }[page];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SiteHeader, {
    items: SITE_NAV,
    active: page,
    onNavigate: go,
    cta: "Start your application",
    ctaCompact: "Apply",
    onCta: () => window.open('https://bit.ly/IYALPHAAPP', '_blank', 'noopener')
  }), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Screen, {
    go: go
  })), /*#__PURE__*/React.createElement(SiteFooter, {
    onNavigate: go,
    columns: [{
      title: 'Program',
      links: [{
        label: 'Highlights',
        id: 'program'
      }, {
        label: 'Apply',
        id: 'apply'
      }]
    }, {
      title: 'Research',
      links: [{
        label: 'Indie Pulse Index',
        id: 'pulse'
      }]
    }, {
      title: 'Organization',
      links: [{
        label: 'About',
        id: 'about'
      }, {
        label: 'Mission and vision',
        id: 'mission'
      }, {
        label: 'Contact',
        href: 'mailto:iymusicoperations@gmail.com'
      }, {
        label: 'Donate',
        href: 'https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser'
      }]
    }],
    note: "Designed by Juel Concepts 2026"
  }));
}
const iyRoot = document.getElementById('root');
if (iyRoot && typeof HomeScreen !== 'undefined' && !iyRoot.dataset.iyMounted) {
  iyRoot.dataset.iyMounted = '1';
  ReactDOM.createRoot(iyRoot).render(/*#__PURE__*/React.createElement(Site, null));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Site.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.PatternPanel = __ds_scope.PatternPanel;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.StarIcon = __ds_scope.StarIcon;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.Disclosure = __ds_scope.Disclosure;

__ds_ns.ChoiceField = __ds_scope.ChoiceField;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.StepIndicator = __ds_scope.StepIndicator;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

})();
