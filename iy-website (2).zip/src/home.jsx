const { Button, Badge, Card, StarIcon, PatternPanel, SectionHeading, StatBlock } = window.IndependentlyYoursDesignSystem_da5bbe;

function HomeScreen({ go }) {
  return (
    <div>
      <PatternPanel tone="teal" hasCopy tile={300}>
        <div className="wrap" style={{ padding:'96px var(--container-pad) 104px', display:'grid', gridTemplateColumns:'minmax(0,1.15fr) minmax(0,.85fr)', gap:'var(--space-8)', alignItems:'center' }}>
          <div>
            <Badge tone="yellow" style={{ marginBottom:'var(--space-5)' }}>First cohort · 2027 · applications open</Badge>
            <h1 style={{ color:'var(--iy-cream-100)', fontSize:'clamp(var(--step-5), 5.4vw, var(--step-7))', margin:'0 0 var(--space-6)' }}>
              Activating Independence as a Strategy
            </h1>
            <div style={{ display:'flex', gap:'var(--space-3)', flexWrap:'wrap' }}>
              <Button size="lg" variant="pulse" href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
              <Button size="lg" variant="inverse-outline" onClick={()=>go('program')}>See the program</Button>
            </div>
          </div>
          <p style={{ color:'var(--iy-cream-100)', fontSize:'var(--step-2)', maxWidth:'42ch', margin:0, lineHeight:1.55 }}>
            Independently Yours is a nonprofit built on a simple idea: Independence does not mean alone, but it does require business acumen.<br/><br/>Cohort style: Twelve weeks, fifteen artists, and a room of people who have done the work dedicated to you each week.
          </p>
        </div>
      </PatternPanel>

      <section className="band">
        <div className="wrap">
          <SectionHeading eyebrow="Curriculum" title="Program &amp; Workshops"
            lead="The twelve-week curriculum will be created bespokely for those in the room and will be shared with the selected applicants." />
          <Button variant="secondary" onClick={()=>go('program')}>See the program</Button>
        </div>
      </section>

      <section style={{ background:'var(--iy-sage-400)' }} className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(min(150px, 100%), 1fr))', gap:'var(--space-5)' }}>
          <StatBlock value="12" label="weeks, start to finish" note="8 weekly sessions + 4 weeks of assessments · Tentatively Thursdays 1-4 pm" />
          <StatBlock value="15" label="artists in the first cohort" note="Selected Applicants will hear by mid December, 2026" />
          <StatBlock value="2027" label="first cohort year" note="Applications close 5 November 2026" />
          <StatBlock value="$0" label="cost to accepted artists" />
        </div>
      </section>


      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--space-8)', alignItems:'center' }}>
          <div>
            <SectionHeading eyebrow="Research" title="The Indie Pulse Index"
              lead="We ask independent artists and fans what they really know about being indie, music discovery and fandom." />
            <p style={{ fontSize:'var(--step-1)' }}>Wave one is in field now. Add your thoughts.</p>
            <div style={{ display:'flex', gap:'var(--space-3)', flexWrap:'wrap' }}>
              <Button variant="pulse" href="https://bit.ly/IPIEVERFAN" target="_blank" rel="noopener">Take the fan survey</Button>
              <Button variant="secondary" onClick={()=>go('pulse')}>About the Index</Button>
            </div>
          </div>
          <Card variant="floated" tone="white" style={{ borderTop:'6px solid var(--iy-yellow-400)' }}>
            <div className="iy-eyebrow" style={{ marginBottom:'var(--space-4)' }}>Wave 1 · in field</div>
            <div style={{ display:'grid', gap:'var(--space-5)' }}>
              <p style={{ margin:0, fontSize:'var(--step-1)' }}>The Indie Pulse Index is bi-annual and free to the public. The first report follows once wave one closes.</p>
            </div>
          </Card>
        </div>
      </section>

      <section className="band" style={{ borderTop:'1.5px solid var(--iy-cream-200)' }}>
        <div className="wrap" style={{ maxWidth:'var(--container-narrow)', textAlign:'center' }}>
          <div className="iy-eyebrow" style={{ marginBottom:'var(--space-4)' }}>With gratitude to our lead sponsor</div>
          <div style={{ fontSize:'clamp(var(--step-4), 4vw, var(--step-5))', fontWeight:700, letterSpacing:'.12em', color:'var(--iy-teal-900)', margin:'0 0 var(--space-5)' }}>CY LEE</div>
          <p style={{ margin:'0 auto', maxWidth:'56ch', fontSize:'var(--step-1)', lineHeight:1.6, textWrap:'pretty' }}>Independently Yours is made possible in part through the generous support of CY Lee. His patronage for artistry and culture helps make this program accessible to the artists who need it most.</p>
          <div style={{ display:'flex', justifyContent:'center', marginTop:'var(--space-6)' }}>
            <Button variant="secondary" href="https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser" target="_blank" rel="noopener">Donate to Independently Yours</Button>
          </div>
        </div>
      </section>

      <PatternPanel tone="cream" hasCopy>
        <div className="wrap" style={{ padding:'var(--section-y-tight) var(--container-pad)', textAlign:'center' }}>
          <h2 style={{ margin:'0 0 var(--space-4)', fontSize:'clamp(var(--step-4), 4vw, var(--step-5))' }}>Applications close 5 November 2026.</h2>
          <p style={{ margin:'0 auto var(--space-6)', maxWidth:'46ch', fontSize:'var(--step-2)' }}>One application, one community survey, no fees.</p>
          <Button size="lg" href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
        </div>
      </PatternPanel>
    </div>
  );
}
