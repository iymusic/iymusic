const { Button, Badge, Card, StarIcon, PatternPanel, SectionHeading, Disclosure } = window.IndependentlyYoursDesignSystem_da5bbe;

const PROGRAM_WORKSHOPS = ['Marketing / Narrative / SWOT Fundamentals', 'Social / Content / Paid Ads', 'Media, PR & Visual Content', 'Sync Licensing', 'Publishing', 'Tech & Content Management', 'Music Business Fundamentals / Monetization', 'Touring & Live Business'];
const PROGRAM_EXTRAS = ['Infrastructure Audit', 'Networking Opportunities'];

const PROGRAM_FOR = [
  'Independent, with no meaningful label development behind them, roughly 3+ years in',
  'Releasing consistently, with a body of work and a clear point of view',
  'Real fans who show up (live shows, email/SMS, Discord, Patreon, Bandcamp): people who do something, not just listen',
  "Some validation (sync, playlists, press, festivals), but music income isn't sustainable yet",
  'Coachable and reliable, ready to activate a release or campaign during the cohort, and willing to share baseline data',
  'Any genre, with LA as the location for the first program. We especially want voices from communities the traditional industry tends to overlook. If they live outside of LA, they can still apply, and we will hold them for future programs.',
  'At this time, we are not accepting AI music projects.'
];
const PROGRAM_NOT_YET = [
  'Artists with no releases or audience yet',
  'Established artists looking for a one-time publicity bump',
  'Anyone expecting guaranteed funding, placements, or a deal',
  'Anyone whose whole strategy hinges on going viral'
];

const PROGRAM_FAQ = [
  { q:'Does it cost anything to apply?', a:'No, and with ongoing donations, it never will.' },
  { q:'Do I need a manager or a lawyer?', a:"No. That's most of the point." },
  { q:'Can I edit my answers after submitting?', a:"No. Answers can't be edited once submitted, so review everything before you send it." },
  { q:'What if I miss the deadline?', a:'The deadline is for the first cohort in 2027. We keep applications for 12 months for consideration in following cohorts.' },
  { q:'What does it cost?', a:'Nothing. The program is free for selected applicants.' },
  { q:'What is expected of me?', a:'Attendance at all 8 weekly sessions, the networking mixer, plus any assessment meetings during the last 4 weeks of the program.' },
  { q:'Where does the program take place?', a:'LA is the location for the first program. We especially want voices from communities the traditional industry tends to overlook. If applicants live outside of LA, they can still apply, and we will hold them for future programs.' },
  { q:'What genres do you accept?', a:'All genres are welcome. At this time, we are not accepting AI music projects.' }
];

function ProgramScreen({ go }) {
  return (
    <div>
      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap">
          <Badge tone="teal" style={{ marginBottom:'var(--space-5)' }}>First cohort · 2027</Badge>
          <h1 style={{ maxWidth:'22ch', margin:'0 0 var(--space-5)', fontSize:'clamp(var(--step-4), 4.6vw, var(--step-6))' }}>The program, in plain terms</h1>
          <p style={{ fontSize:'var(--step-2)', maxWidth:'52ch' }}>Twelve weeks of business practice for independent artists: what you own, what it earns, and how you run it next year without a label doing it for you.</p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:'var(--space-3)', marginTop:'var(--space-5)' }}>
            <Button href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
            <Button variant="secondary" onClick={()=>go('pulse')}>See the research</Button>
          </div>
        </div>
      </section>

      <section className="band">
        <div className="wrap">
          <SectionHeading eyebrow="Curriculum" title="Program &amp; Workshops"
            lead="The twelve-week curriculum will be created bespokely for those in the room and will be shared with the selected applicants prior to the start of the program." />
          <ol style={{ listStyle:'none', margin:0, padding:0, display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(min(210px, 100%), 1fr))', gap:'var(--space-6) var(--space-5)' }}>
            {PROGRAM_WORKSHOPS.map((w, i) => (
              <li key={w} style={{ borderTop:'3px solid var(--iy-sage-400)', paddingTop:'var(--space-4)' }}>
                <div style={{ fontSize:'var(--step--1)', color:'var(--text-muted)', fontWeight:700, marginBottom:'var(--space-2)' }}>0{i + 1}</div>
                <div style={{ fontSize:'var(--step-1)', fontWeight:700, lineHeight:1.3, color:'var(--iy-teal-900)', textWrap:'pretty' }}>{w}</div>
              </li>
            ))}
          </ol>
          <div style={{ marginTop:'var(--space-7)', display:'flex', flexWrap:'wrap', alignItems:'center', gap:'var(--space-4)' }}>
            <div className="iy-eyebrow">Plus</div>
            {PROGRAM_EXTRAS.map(x => (
              <Card key={x} variant="drawn" tone="cream" style={{ padding:'var(--space-4) var(--space-5)', fontSize:'var(--step-1)', fontWeight:700, color:'var(--iy-teal-900)' }}>{x}</Card>
            ))}
          </div>
        </div>
      </section>

      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap">
          <SectionHeading eyebrow="Who this is for" title="Audience-ready, but needs system infrastructure" />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(min(320px, 100%), 1fr))', gap:'var(--space-5)', alignItems:'start' }}>
            <Card variant="drawn" tone="white">
              <h4 style={{ margin:'0 0 var(--space-4)' }}>A good fit</h4>
              <div style={{ display:'grid', gap:'var(--space-3)' }}>
                {PROGRAM_FOR.map(i => (
                  <div key={i} style={{ display:'flex', gap:'var(--space-3)', alignItems:'flex-start' }}>
                    <StarIcon size={16} style={{ flex:'0 0 auto', marginTop:4 }} />
                    <p style={{ margin:0, fontSize:'var(--step-0)', textWrap:'pretty' }}>{i}</p>
                  </div>
                ))}
              </div>
              <p style={{ margin:'var(--space-5) 0 0', paddingTop:'var(--space-4)', borderTop:'1.5px solid var(--iy-cream-200)', fontSize:'var(--step-0)', fontStyle:'italic' }}>As a gut check, 10K–75K monthly listeners is a helpful signal, not a requirement.</p>
            </Card>
            <Card variant="drawn" tone="cream">
              <h4 style={{ margin:'0 0 var(--space-4)' }}>Probably not the right fit (yet)</h4>
              <ul style={{ margin:0, paddingLeft:'1.1em', display:'grid', gap:'var(--space-3)', fontSize:'var(--step-0)' }}>
                {PROGRAM_NOT_YET.map(i => <li key={i}>{i}</li>)}
              </ul>
            </Card>
          </div>
          <p style={{ margin:'var(--space-7) 0 0', maxWidth:'48ch', fontSize:'var(--step-2)', lineHeight:1.4, color:'var(--iy-teal-900)', textWrap:'pretty' }}>Our favorite shorthand: proof of promise, proof of effort, and proof of audience, but not yet proof of a repeatable business model.</p>
        </div>
      </section>

      <PatternPanel tone="teal" hasCopy>
        <div className="wrap band">
          <div style={{ maxWidth:'60rem' }}>
            <SectionHeading tone="light" eyebrow="How it runs" title="TENTATIVELY - Thursdays from 1-4 pm in Hollywood, CA"
              lead="Short Lectures, Discussions, Panels, Workshops and Real Talk." />
            <p style={{ color:'var(--iy-cream-100)', fontSize:'var(--step-1)' }}>8 weekly sessions, then 4 weeks of assessments. Fifteen artists in the room so every session can look at your real pain points. The date, time, session length and location are tentative til January 2027.</p>
            <div className="iy-accent" style={{ color:'var(--iy-yellow-400)', marginTop:'var(--space-4)' }}>In 12 weeks, you'll build business acumen to reign supreme as the CEO of your own empire.</div>
          </div>
        </div>
      </PatternPanel>

      <section className="band">
        <div className="wrap" style={{ maxWidth:'var(--container-narrow)' }}>
          <SectionHeading eyebrow="Questions" title="Before you apply" />
          <Disclosure items={PROGRAM_FAQ} defaultOpen={0} />
          <div style={{ display:'flex', alignItems:'center', gap:'var(--space-3)', marginTop:'var(--space-7)' }}>
            <StarIcon size={18} />
            <Button href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
