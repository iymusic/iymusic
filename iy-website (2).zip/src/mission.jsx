const { Button: MissionButton, Badge: MissionBadge, StarIcon: MissionStar, PatternPanel: MissionPattern, SectionHeading: MissionHeading } = window.IndependentlyYoursDesignSystem_da5bbe;

const MISSION_WORKSHOPS = ['Marketing / Narrative / SWOT Fundamentals', 'Social / Content / Paid Ads', 'Media, PR & Visual Content', 'Sync Licensing', 'Publishing', 'Tech & Content Management', 'Music Business Fundamentals / Monetization', 'Touring & Live Business'];

function MissionScreen({ go }) {
  const eyebrow = { fontSize:'var(--step--1)', fontWeight:700, letterSpacing:'.16em', textTransform:'uppercase', margin:'0 0 var(--space-4)' };
  return (
    <div>
      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr) minmax(0,1.1fr)', gap:'var(--space-8)', alignItems:'start' }}>
          <div>
            <MissionBadge tone="teal" style={{ marginBottom:'var(--space-5)' }}>Mission</MissionBadge>
            <h1 style={{ margin:0, fontSize:'clamp(var(--step-3), 3.6vw, var(--step-5))', lineHeight:1.15, textWrap:'pretty' }}>To empower independent artists with education, mentorship, community, and industry opportunities.</h1>
          </div>
          <p style={{ fontSize:'var(--step-1)', lineHeight:1.6, margin:'var(--space-8) 0 0', textWrap:'pretty' }}>Our mission is to make independence not just possible—but profitable and sustainable. We are building a new economic engine for artist freedom with a transparent infrastructure of mentorship, funding, and data—empowering artists to control their own narratives without giving up their masters.</p>
        </div>
      </section>

      <section className="band">
        <div className="wrap">
          <MissionHeading eyebrow="Workshops" title="What we teach" />
          <ol style={{ listStyle:'none', margin:0, padding:0, display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(min(210px, 100%), 1fr))', gap:'var(--space-6) var(--space-5)' }}>
            {MISSION_WORKSHOPS.map((w, i) => (
              <li key={w} style={{ borderTop:'3px solid var(--iy-sage-400)', paddingTop:'var(--space-4)' }}>
                <div style={{ fontSize:'var(--step--1)', color:'var(--text-muted)', fontWeight:700, marginBottom:'var(--space-2)' }}>0{i + 1}</div>
                <div style={{ fontSize:'var(--step-1)', fontWeight:700, lineHeight:1.3, color:'var(--iy-teal-900)', textWrap:'pretty' }}>{w}</div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <MissionPattern tone="teal" hasCopy>
        <div className="wrap band" style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr) minmax(0,1.1fr)', gap:'var(--space-8)', alignItems:'start' }}>
          <div>
            <div style={{ ...eyebrow, color:'var(--iy-sage-200)' }}>Vision</div>
            <h2 style={{ margin:0, color:'var(--iy-cream-100)', fontSize:'clamp(var(--step-3), 3.6vw, var(--step-5))', lineHeight:1.15, textWrap:'pretty' }}>To be the leading resource and accelerator for indie music creators, bridging the gap between artistry, business, and community impact.</h2>
          </div>
          <p style={{ color:'var(--iy-cream-100)', fontSize:'var(--step-1)', lineHeight:1.6, margin:'var(--space-8) 0 0', textWrap:'pretty' }}>We are building a music industry where the 0.1% who break through becomes the many — where artistic independence is the most competitive, most sustainable, and most sought-after path in music. A world where artists never have to choose between their art and their autonomy.</p>
        </div>
        <div className="wrap" style={{ paddingBottom:'var(--section-y)' }}>
          <div style={{ borderTop:'1px solid rgba(242,231,215,.3)', paddingTop:'var(--space-7)' }}>
            <p style={{ margin:0, color:'var(--iy-cream-100)', fontSize:'clamp(var(--step-3), 3.4vw, var(--step-5))', lineHeight:1.2 }}>Where independence isn't just an option.<br/><span style={{ color:'var(--iy-yellow-400)', fontWeight:700 }}>It's THE choice.</span></p>
          </div>
        </div>
      </MissionPattern>

      <section className="band">
        <div className="wrap" style={{ display:'flex', flexWrap:'wrap', alignItems:'center', gap:'var(--space-3)' }}>
          <MissionStar size={18} />
          <MissionButton href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</MissionButton>
          <MissionButton variant="secondary" onClick={()=>go('program')}>See the program</MissionButton>
        </div>
      </section>
    </div>
  );
}
