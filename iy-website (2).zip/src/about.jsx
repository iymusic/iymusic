const { Button: AboutButton, Badge: AboutBadge, PatternPanel: AboutPattern, SectionHeading: AboutHeading } = window.IndependentlyYoursDesignSystem_da5bbe;

const ABOUT_PILLARS = ['Community', 'Education', 'Data'];

function AboutScreen({ go }) {
  return (
    <div>
      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap">
          <AboutBadge tone="teal" style={{ marginBottom:'var(--space-5)' }}>About</AboutBadge>
          <h1 style={{ maxWidth:'20ch', margin:'0 0 var(--space-5)', fontSize:'clamp(var(--step-4), 4.6vw, var(--step-6))' }}>Built to put artists first</h1>
          <p style={{ fontSize:'var(--step-1)', maxWidth:'64ch', lineHeight:1.6, textWrap:'pretty' }}>Independently Yours is a platform and community built to put artists first—offering education, workshops, and mentorship, while delivering biannual consumer insights grounded in real fan data. It creates spaces for connection through events, showcases, and both digital and real-world communities. By doing so, it empowers artists, fans, and industry allies to come together with the shared mission of shifting the music industry—making independence not just possible, but a powerful and intentional choice, driven by community, data, and artist-led values.</p>
        </div>
      </section>

      <AboutPattern tone="teal" hasCopy>
        <div className="wrap band" style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr) minmax(0,1.2fr)', gap:'var(--space-8)', alignItems:'start' }}>
          <h2 style={{ margin:0, color:'var(--iy-cream-100)', fontSize:'clamp(var(--step-4), 4vw, var(--step-6))' }}>It’s a movement.</h2>
          <div>
            <p style={{ color:'var(--iy-cream-100)', fontSize:'var(--step-2)', lineHeight:1.5, margin:'0 0 var(--space-6)', textWrap:'pretty' }}>By helping artists grow their careers on their own terms, we aim to redefine success in the music industry. Our growth strategy prioritizes community, education, and data as the foundation of long-term sustainability.</p>
            <div style={{ display:'flex', flexWrap:'wrap', gap:'var(--space-3)' }}>
              {ABOUT_PILLARS.map(p => (
                <span key={p} style={{ border:'1.5px solid var(--iy-sage-400)', color:'var(--iy-cream-100)', borderRadius:'var(--radius-pill)', padding:'8px 18px', fontSize:'var(--step-0)', fontWeight:700 }}>{p}</span>
              ))}
            </div>
          </div>
        </div>
      </AboutPattern>

      <section className="band">
        <div className="wrap" style={{ display:'flex', flexWrap:'wrap', gap:'var(--space-8)', alignItems:'flex-start' }}>
          <figure style={{ margin:0, flex:'0 1 320px', minWidth:220 }}>
            <img src={(window.IY_ASSET_BASE || '../../assets/') + 'kristin-juel-web.jpg'} alt="Kristin Juel seated on a Vox amp against an orange backdrop" style={{ display:'block', width:'100%', aspectRatio:'4 / 5', objectFit:'cover', objectPosition:'50% 30%', borderRadius:'var(--radius-md)' }} />
            <figcaption style={{ marginTop:'var(--space-2)', fontFamily:'var(--font-ui)', fontSize:'var(--step--1)', color:'var(--text-muted)' }}>Photo: Elaine Torres</figcaption>
          </figure>
          <div style={{ flex:'1 1 420px', minWidth:0 }}>
            <div className="iy-eyebrow" style={{ marginBottom:'var(--space-3)' }}>Meet the Founder</div>
            <h2 style={{ margin:'0 0 var(--space-2)', fontSize:'clamp(var(--step-4), 4vw, var(--step-5))' }}>Kristin Juel</h2>
            <p style={{ margin:'0 0 var(--space-6)', fontSize:'var(--step-1)', fontWeight:700, color:'var(--iy-sage-600)' }}>Founder/President &amp; Executive Director</p>
            <div style={{ display:'flex', flexDirection:'column', gap:'var(--space-4)', fontSize:'var(--step-1)', lineHeight:1.6, maxWidth:'64ch', textWrap:'pretty' }}>
              <p style={{ margin:0 }}>Kristin Juel is the founder of both Independently Yours (501c3 established in 2026) and Juel Concepts, a music marketing and management firm established in 2013, which applies her two decades of brand-building experience (e.g., Nissan, KFC, Kaiser Permanente) to empower independent artists for the data-driven industry. Her work, guided by tenets of passionate, proactive, and transparent service, has helped elevate artists like Hamish Anderson and Shelly Peiken.</p>
              <p style={{ margin:0 }}>Additionally, Kristin was a Senior Analyst for Water &amp; Music, specializing in AI music, Web3, and the metaverse, and she actively supports the industry as a Governor on the LA Chapter of the Recording Academy, an advisor to startups and through mentorship with organizations like Grammy U.</p>
              <p style={{ margin:0 }}>She has rewritten the curriculum and is teaching the Music Business Marketing Courses at Musician’s Institute and the DIY Artist Marketing Course at UCLA’s Luskin School.</p>
              <p style={{ margin:0 }}>Kristin resides in Los Angeles, where she is an avid member of the live-music-rocks-any-night-of-the-week club.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="band">
        <div className="wrap" style={{ display:'flex', flexWrap:'wrap', alignItems:'center', justifyContent:'space-between', gap:'var(--space-5)' }}>
          <AboutHeading eyebrow="Next" title="Mission and Vision" />
          <div style={{ display:'flex', gap:'var(--space-3)' }}>
            <AboutButton onClick={()=>go('mission')}>Read our mission</AboutButton>
            <AboutButton variant="secondary" onClick={()=>go('program')}>See the program</AboutButton>
          </div>
        </div>
      </section>
    </div>
  );
}
