# Independently Yours website (iymusic.org)

Plain static site. Vercel serves it as-is: no build step, no framework.

- `index.html` - the page shell (title, SEO tags, analytics)
- `css/styles.css` - brand colors, type, and mobile layout
- `assets/` - logos, star patterns, founder photo
- `js/` - the compiled site (do not edit by hand)
- `src/` - the editable page content (one file per page)
- `tools/` - the script that turns `src/` into `js/`

## Updating the site
1. Edit the text in `src/<page>.jsx` (home, about, mission, program, apply, pulse).
2. Run `cd tools && npm install && node build.js` to rebuild `js/site.js`.
3. Commit and push to GitHub. Vercel redeploys automatically in about a minute.

Images: replace a file in `assets/` with one of the same name and push.
