const { SiteHeader, SiteFooter } = window.IndependentlyYoursDesignSystem_da5bbe;

const SITE_NAV = [
  { id:'home', label:'Home' },
  { id:'about', label:'About' },
  { id:'mission', label:'Mission' },
  { id:'program', label:'Program' },
  { id:'pulse', label:'Indie Pulse Index' },
  { id:'donate', label:'Donate', href:'https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser' }
];

function Site() {
  const SITE_PAGES = ['home','about','mission','program','apply','pulse'];
  const fromHash = () => { const h = location.hash.slice(1); return SITE_PAGES.includes(h) ? h : 'home'; };
  const [page, setPage] = React.useState(fromHash);
  React.useEffect(() => { const on = () => setPage(fromHash()); window.addEventListener('hashchange', on); return () => window.removeEventListener('hashchange', on); }, []);
  React.useEffect(() => {
    window.scrollTo(0, 0); if (window.lucide) window.lucide.createIcons();
    (window.dataLayer = window.dataLayer || []).push({ event:'virtual_page_view', page_path:'/' + (page === 'home' ? '' : page), page_title:page });
  }, [page]);
  const go = (id) => { if (location.hash.slice(1) !== id) location.hash = id; setPage(id); };
  const Screen = { home: HomeScreen, program: ProgramScreen, apply: ApplyScreen, pulse: PulseScreen, about: AboutScreen, mission: MissionScreen }[page];
  return (
    <div>
      <SiteHeader items={SITE_NAV} active={page} onNavigate={go} cta="Start your application" ctaCompact="Apply" onCta={()=>window.open('https://bit.ly/IYALPHAAPP','_blank','noopener')} />
      <main><Screen go={go} /></main>
      <SiteFooter onNavigate={go}
        columns={[
          { title:'Program', links:[{label:'Highlights',id:'program'},{label:'Apply',id:'apply'}] },
          { title:'Research', links:[{label:'Indie Pulse Index',id:'pulse'}] },
          { title:'Organization', links:[{label:'About',id:'about'},{label:'Mission and vision',id:'mission'},{label:'Contact',href:'mailto:iymusicoperations@gmail.com'},{label:'Donate',href:'https://creative-visions.networkforgood.com/projects/299157-independently-yours-s-fundraiser'}] }
        ]}
        note="Designed by Juel Concepts 2026" />
    </div>
  );
}
const iyRoot = document.getElementById('root');
if (iyRoot && typeof HomeScreen !== 'undefined' && !iyRoot.dataset.iyMounted) { iyRoot.dataset.iyMounted = '1'; ReactDOM.createRoot(iyRoot).render(<Site />); }
