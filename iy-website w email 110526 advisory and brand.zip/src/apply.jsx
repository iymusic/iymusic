const { Button, Badge, Card, StarIcon, PatternPanel, SectionHeading, Disclosure } = window.IndependentlyYoursDesignSystem_da5bbe;

const APPLY_NEEDS = [
  'Your artist or project name as it appears on streaming.',
  'Links to your work',
  'A rough sense of what you earned from music last year. Ranges are fine.',
  'Two or three sentences on what you want to achieve by the end of the twelve weeks.'
];

const APPLY_ELIGIBLE = [
  "You're an independent musician, band or artist project and you've released music already, at any scale, in any genre. (This program is for musicians, not visual artists. We are not considering AI music projects this time.)",
  'You have a community that engages: fans who come to shows, buy merch, join your list or support you directly. At least 15 of them will need to answer the short fan survey included in the application.',
  'You handle your own business, or want to. You desire autonomy and to lead a team to achieve your vision.',
  'You can commit to all 8 weekly sessions, the networking mixer, and any assessment meetings in the last 4 weeks.',
  'The first program takes place in LA. If you live outside of LA, you can still apply, and we will hold your application for 12 months to attend future programs.'
];

const APPLY_NEXT = [
  { n:'1', t:'We read everything after the deadline', d:"Not as they arrive, so applying early doesn't help you and applying late doesn't work at all." },
  { n:'2', t:'You might get a short call', d:"If you're being considered, we may reach out for a short call." },
  { n:'3', t:'Selected musicians hear by 30 December', d:'You will only be notified upon selection, by 30 December 2026.' }
];

const APPLY_FAQ = [
  { q:'Can I edit my answers after submitting?', a:"No. Answers can't be edited once submitted, so review everything before you send it." },
  { q:'Do I need a manager or a lawyer?', a:"No. That's most of the point." },
  { q:'Does it cost anything to apply?', a:'No, and with ongoing donations, it never will.' },
  { q:'What if I miss the deadline?', a:'The deadline is for the first cohort in 2027. We keep applications for 12 months for consideration in following cohorts.' }
];

function ApplyScreen({ go }) {
  return (
    <div>
      <PatternPanel tone="cream" hasCopy tile={300}>
        <div className="wrap" style={{ padding:'var(--section-y-tight) var(--container-pad)' }}>
          <div className="iy-shade iy-shade--cream">
          <Badge tone="teal" style={{ marginBottom:'var(--space-5)' }}>First cohort · 15 musicians · 2027</Badge>
          <h1 style={{ maxWidth:'22ch', margin:'0 0 var(--space-5)', fontSize:'clamp(var(--step-4), 4.6vw, var(--step-6))' }}>One application, one fan survey, no fees</h1>
          <p style={{ fontSize:'var(--step-2)', maxWidth:'52ch', margin:0 }}>Applications close 30 November 2026. Read the two lists below first, they'll save you a rewrite.</p>
          </div>
        </div>
      </PatternPanel>

      <section className="band">
        <div className="wrap" style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--space-5)' }}>
          {[['What you\u2019ll need', APPLY_NEEDS], ['Who can apply', APPLY_ELIGIBLE]].map(([title, items]) => (
            <Card key={title} variant="drawn" tone="white">
              <h4 style={{ margin:'0 0 var(--space-4)' }}>{title}</h4>
              <div style={{ display:'grid', gap:'var(--space-3)' }}>
                {items.map(i => (
                  <div key={i} style={{ display:'flex', gap:'var(--space-3)', alignItems:'flex-start' }}>
                    <StarIcon size={16} style={{ flex:'0 0 auto', marginTop:4 }} />
                    <p style={{ margin:0, fontSize:'var(--step-0)' }}>{i}</p>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section style={{ background:'var(--iy-cream-100)' }} className="band">
        <div className="wrap" style={{ maxWidth:'var(--container-narrow)' }}>
          <SectionHeading eyebrow="The application" title="Before you start"
            lead="Submit once. Answers can't be edited after you submit." />
          <div style={{ display:'flex', flexDirection:'column', gap:'var(--space-4)', alignItems:'flex-start' }}>
            <p style={{ margin:0, fontSize:'var(--step-1)', lineHeight:1.6, maxWidth:'60ch' }}>Your application includes a short survey to share with your fans and collaborators. At least 15 need to respond, and their answers count for 25% of our review. Community is the strongest signal we look for.</p>
            <Button size="lg" href="https://bit.ly/IYALPHAAPP" target="_blank" rel="noopener">Start your application</Button>
          </div>
          <Card variant="floated" tone="white" style={{ marginTop:'var(--space-7)', borderTop:'6px solid var(--iy-yellow-400)', display:'flex', flexDirection:'column', gap:'var(--space-3)', alignItems:'flex-start' }}>
            <Badge tone="yellow">Already applied?</Badge>
            <h3 style={{ margin:0, fontSize:'var(--step-3)' }}>Send your fans here</h3>
            <p style={{ margin:0, fontSize:'var(--step-1)', maxWidth:'58ch' }}>This is the survey for your community, not the general Indie Pulse survey. Ask fans to type your artist name exactly as you applied, so their answers count for you.</p>
            <Button href="https://bit.ly/IYIPALPHAFAN" target="_blank" rel="noopener" style={{ whiteSpace:'normal', textAlign:'center', maxWidth:'100%' }}>Open the artist fan survey</Button>
            <p style={{ margin:0, fontSize:'var(--step-0)', color:'var(--text-muted)' }}>Copy this link to share: bit.ly/IYIPALPHAFAN</p>
          </Card>
        </div>
      </section>

      <section style={{ background:'var(--iy-sage-400)' }} className="band">
        <div className="wrap">
          <SectionHeading eyebrow="What happens next" title="The Path Ahead" />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'var(--space-5)' }}>
            {APPLY_NEXT.map(s => (
              <Card key={s.n} variant="drawn" tone="white">
                <Badge tone="teal" style={{ marginBottom:'var(--space-4)' }}>{s.n}</Badge>
                <h4 style={{ margin:'0 0 var(--space-3)' }}>{s.t}</h4>
                <p style={{ fontSize:'var(--step-0)', margin:0 }}>{s.d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="band">
        <div className="wrap" style={{ maxWidth:'var(--container-narrow)' }}>
          <SectionHeading eyebrow="Application FAQ" title="Before you ask" />
          <Disclosure items={APPLY_FAQ} defaultOpen={0} />
        </div>
      </section>
    </div>
  );
}
