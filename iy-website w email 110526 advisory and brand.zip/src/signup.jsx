const { Button: SignupButton, SectionHeading: SignupHeading } = window.IndependentlyYoursDesignSystem_da5bbe;

/* "Stay close" signup band. Posts to a Google Form (free) and logs a signup event.
   The visitor picks who they are; the promise changes to match, and the role
   lands in the CRM sheet as a ready-made segment.
   Renders nothing until window.IY_SIGNUP.action is set in index.html. */
const SIGNUP_ROLES = [
  { id:'Musician', label:'a musician', promise:'Free business tools, workshop invites and first word on the next cohort.' },
  { id:'Fan', label:'a fan', promise:'Indie Pulse Index findings and the independent artists to watch, before everyone else.' },
  { id:'Industry', label:'in the industry', promise:'Early looks at the cohort, the data behind the Index, and ways to mentor.' },
  { id:'Supporter or donor', label:'a supporter', promise:'Meet the musicians you are backing, and see what your support builds.' }
];

function SignupBand({ page }) {
  const cfg = window.IY_SIGNUP || {};
  const [state, setState] = React.useState('idle');
  const [email, setEmail] = React.useState('');
  const [name, setName] = React.useState('');
  const [role, setRole] = React.useState('Musician');
  if (!cfg.action || !cfg.fields || !cfg.fields.email) return null;
  const pick = SIGNUP_ROLES.find(r => r.id === role) || SIGNUP_ROLES[0];

  const submit = (e) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { setState('bad'); return; }
    const f = cfg.fields, body = new URLSearchParams();
    body.append(f.email, email.trim());
    if (f.name && name.trim()) body.append(f.name, name.trim());
    if (f.role) body.append(f.role, role);
    if (f.source) body.append(f.source, (window.iySource || 'direct/none') + ' @' + page);
    setState('sending');
    fetch(cfg.action, { method:'POST', mode:'no-cors', body })
      .then(() => { setState('done'); if (window.iyTrack) window.iyTrack('signup'); })
      .catch(() => setState('error'));
  };

  const field = { font:'inherit', fontSize:'var(--step-0)', padding:'12px 14px', borderRadius:'var(--radius-md)', border:'1.5px solid var(--iy-teal-900)', background:'#fff', color:'inherit', minWidth:0, width:'100%', height:52, boxSizing:'border-box' };

  return (
    <section className="band iy-signup" style={{ background:'var(--iy-cream-100)', borderTop:'1.5px solid rgba(1,64,69,.15)' }}>
      <div className="wrap" style={{ maxWidth:'var(--container-narrow)' }}>
        <SignupHeading eyebrow="Independent doesn’t mean alone" title="Stay close" />
        {state === 'done' ? (
          <p role="status" style={{ fontSize:'var(--step-1)', margin:0 }}>You’re in{name.trim() ? ', ' + name.trim() : ''}. Welcome to the corner.</p>
        ) : (
          <form onSubmit={submit} noValidate style={{ display:'grid', gap:'var(--space-5)' }}>
            <fieldset className="iy-role">
              <legend>I’m…</legend>
              {SIGNUP_ROLES.map(r => (
                <label key={r.id}>
                  <input type="radio" name="iy-role" id={'iy-role-' + r.label.replace(/\W+/g, '-')} value={r.id} checked={role === r.id} onChange={() => setRole(r.id)} />
                  <span>{r.label}</span>
                </label>
              ))}
            </fieldset>
            <p aria-live="polite" style={{ margin:0, fontSize:'var(--step-1)', lineHeight:1.5, maxWidth:'52ch' }}>{pick.promise}</p>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(min(200px, 100%), 1fr))', gap:'var(--space-3)', alignItems:'end' }}>
              <label style={{ display:'grid', gap:6, fontSize:'var(--step-0)' }}>Email
                <input id="iy-signup-email" type="email" required autoComplete="email" value={email} onChange={e=>{ setEmail(e.target.value); if (state==='bad') setState('idle'); }} style={field} aria-invalid={state==='bad'} />
              </label>
              <label style={{ display:'grid', gap:6, fontSize:'var(--step-0)' }}>First name (optional)
                <input id="iy-signup-name" type="text" autoComplete="given-name" value={name} onChange={e=>setName(e.target.value)} style={field} />
              </label>
              <SignupButton size="lg" type="submit" disabled={state==='sending'}>{state==='sending' ? 'Sending…' : 'Count me in'}</SignupButton>
            </div>
            {state === 'bad' && <p role="alert" style={{ margin:0, color:'#8a1c1c' }}>That email doesn’t look right.</p>}
            {state === 'error' && <p role="alert" style={{ margin:0, color:'#8a1c1c' }}>That didn’t go through. Try again, or email iymusicoperations@gmail.com.</p>}
          </form>
        )}
      </div>
    </section>
  );
}
